#!/usr/bin/python

import rospy
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Joy

scale_x = 4
scale_y = 4
axis_x = 1
axis_y = 0

def callback(data) :
	global scale_x, scale_y
	twist = Twist()
	twist.linear.x =  scale_x*data.axes[axis_x]
	twist.angular.z = scale_y*data.axes[axis_y]
	pub.publish(twist)
	
def start() :
	global pub
	global scale_x, scale_y
	rospy.init_node('vrep_joystick')
	scale_x = rospy.get_param("~scale_x",scale_x)
	scale_y = rospy.get_param("~scale_y",scale_y)
	pub = rospy.Publisher('/vrep/twistCommand', Twist, queue_size=1)
	rospy.Subscriber("/joy",Joy,callback)
	rospy.loginfo("Joystick driver running")
	rospy.spin()
#print(__name__)	
if __name__ == '__main__':
	start()



