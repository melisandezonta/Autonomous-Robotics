#!/usr/bin/env python
import roslib;

roslib.load_manifest('rover_driver')
import rospy
from geometry_msgs.msg import Twist
import numpy
from numpy.linalg import pinv
from math import atan2, hypot, pi, cos, sin, fmod

prefix=["FL","FR","CL","CR","RL","RR"]

class RoverMotors:
    def __init__(self):
        self.steering={}
        self.drive={}
        for k in prefix:
            self.steering[k]=0.0
            self.drive[k]=0.0
    def copy(self,value):
        for k in prefix:
            self.steering[k]=value.steering[k]
            self.drive[k]=value.drive[k]

class DriveConfiguration:
    def __init__(self,radius,x,y,z):
        self.x = x
        self.y = y
        self.z = z
        self.radius = radius


class RoverKinematics:
    def __init__(self):
        self.X = numpy.asmatrix(numpy.zeros((3,1)))
        self.motor_state = RoverMotors()
        self.first_run = True

    def twist_to_motors(self, twist, drive_cfg, skidsteer=False):
        motors = RoverMotors()
        if skidsteer:
            for k in drive_cfg.keys():
                # Insert here the steering and velocity of 
                # each wheel in skid-steer mode
                vw_x = twist.linear.x - twist.angular.z* drive_cfg[k].y
                vw_y = 0
                motors.steering[k] = 0
                motors.drive[k] = vw_x / drive_cfg[k].radius
        else:
            for k in drive_cfg.keys():
                # Insert here the steering and velocity of 
                # each wheel in rolling-without-slipping mode
                vw_x = twist.linear.x - twist.angular.z* drive_cfg[k].y
                vw_y = twist.linear.y + twist.angular.z* drive_cfg[k].x
                motors.drive[k] = hypot(vw_y, vw_x) / drive_cfg[k].radius
                motors.steering[k] = fmod(atan2(vw_y,vw_x)+pi/2, 2*pi) - pi/2
        return motors

    def compute_inversion(self,motor_state,drive_cfg):
        A = numpy.asmatrix(numpy.zeros((len(drive_cfg.keys()) * 2,3)))
        B = numpy.asmatrix(numpy.zeros((len(drive_cfg.keys()) * 2,1)))
        for (i, k) in enumerate(drive_cfg.keys()):
            # Computation of A
            A[2*i,   :] = [1, 0, -drive_cfg[k].y]
            A[2*i+1, :] = [0, 1,  drive_cfg[k].x]
            # Computation of ds and beta
            ds = (fmod((motor_state.drive[k] - self.motor_state.drive[k])+3*pi, 2*pi) - pi) * drive_cfg[k].radius
            beta = motor_state.steering[k]
            # Computation of B
            B[2*i]      = ds * cos(beta)
            B[2*i+1]    = ds * sin(beta)
        return pinv(A) * B

    def integrate_odometry(self, motor_state, drive_cfg):

        # The first time, we need to initialise the state
        if self.first_run:
            self.motor_state.copy(motor_state)
            self.first_run = False
            self.X = numpy.zeros((3,1))
            return self.X
        dX = self.compute_inversion(motor_state,drive_cfg)

        # Insert here your odometry code
        self.X[0,0] += dX[0,0]*cos(self.X[2,0]) - dX[1,0]*sin(self.X[2,0])
        self.X[1,0] += dX[0,0]*sin(self.X[2,0]) + dX[1,0]*cos(self.X[2,0])
        self.X[2,0] += dX[2,0]
        self.motor_state.copy(motor_state)
        return self.X



