#!/usr/bin/python
# ROS specific imports
import roslib;

roslib.load_manifest('floor_nav')
import rospy
from math import *
from task_manager_lib.TaskClient import *

rospy.init_node('task_client')
server_node = rospy.get_param("~server", "/task_server")
default_period = rospy.get_param("~period", 0.05)
tc = TaskClient(server_node, default_period)
rospy.loginfo("Mission connected to server: " + server_node)

mission_time_minutes = 6.

tc.WaitForAuto()
id = tc.MonitorBattery(foreground=False)
tc.addCondition(ConditionIsCompleted("BatteryLow", tc, id))
id_wait = tc.Wait(duration=mission_time_minutes * 60.0, foreground=False)
tc.addCondition(ConditionIsCompleted("TimeOut", tc, id_wait))
tc.Constant(duration=3, linear=-0.15)
try:
    while True:
        # Turn around
        rospy.loginfo("Sensor sweep...")
        for angle in [pi / 2, pi, 3 * pi / 2, 0.0]:
            tc.SetHeading(target=angle, k_theta=1.5, max_angular_velocity=1.5)
        # Explore
        rospy.loginfo("Launching explore...")
        try:
            tc.Explore()
        except TaskException, e:
            rospy.loginfo("Explore failed.")
            pass
        else:
            rospy.loginfo("Done exploring.")
        tc.Wait(duration=1.0)
        tc.WaitForAuto()
except TaskConditionException, e:
    rospy.loginfo("Path following interrupted on condition: %s" % \
                  " or ".join([str(c) for c in e.conditions]))
    # This means the conditions were triggered. We need to react to it
    # Conditions are cleared on trigger
    conditions = [str(c) for c in e.conditions]
    if "BatteryLow" in conditions:
        rospy.loginfo("Low on battery. Returning to base")
        try:
            tc.PlanTo(goal_x=-1, goal_y=0, goal_theta=0.0)
        except TaskException, e:
            rospy.logerr("Cannot plan to position. Using GoTo instead...")
            tc.GoToPose(goal_x=-1, goal_y=0, goal_theta=0, smart_method=True)
        tc.ActionGoToDock()
    elif "TimeOut" in conditions:
        rospy.loginfo("Mission timed out. Returning to base")
        try:
            tc.PlanTo(goal_x=-0.8, goal_y=0, goal_theta=0.0)
        except TaskException, e:
            try:
                tc.PlanTo(goal_x=-1, goal_y=0, goal_theta=0.0)
            except TaskException, e:
                rospy.logerr("Cannot plan to position. Using GoTo instead...")
                tc.GoToPose(goal_x=-1, goal_y=0, goal_theta=0, smart_method=True)
        tc.ActionGoToDock()
    else:
        rospy.loginfo("Mission aborted")
except TaskException, e:
    rospy.logerr("Exception caught: " + str(e))
    if not rospy.core.is_shutdown():
        tc.SetManual()

rospy.loginfo("Mission completed")
