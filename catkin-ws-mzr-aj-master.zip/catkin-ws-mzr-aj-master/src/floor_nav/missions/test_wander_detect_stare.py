#!/usr/bin/python
# ROS specific imports
import roslib; roslib.load_manifest('floor_nav')
import rospy
from math import *
from random import *
from task_manager_lib.TaskClient import *

rospy.init_node('task_client')
server_node = rospy.get_param("~server","/task_server")
default_period = rospy.get_param("~period",0.05)
tc = TaskClient(server_node,default_period)
rospy.loginfo("Mission connected to server: " + server_node)

scale=2.0
vel=0.5

tc.WaitForAuto()
id = tc.WaitForFace(radius = 1.0,foreground=False)
tc.addCondition(ConditionIsCompleted("WaitedForFace",tc,id))
try:
    tc.Wander(front_sector=False, angular_range=40, max_linear_speed=0.4, safety_range=2.0)
    tc.clearConditions()
    tc.stopTask(id)
except TaskConditionException, e:
    rospy.loginfo("Path following interrupted on condition: %s" % \
                  " or ".join([str(c) for c in e.conditions]))
    # This means the conditions were triggered. We need to react to it
    # Conditions are cleared on trigger
    if "WaitedForFace" in [str(c) for c in e.conditions]:
        rospy.loginfo("Face found")
        tc.StareAtFace(max_angular_velocity = 1.0, angle_threshold = 0.1, k_theta=0.2)
        rospy.loginfo("Stared at face. Looking elsewhere...")
        tc.SetHeading(target = pi, relative = True, max_angular_velocity = 2.0)
    else:
        rospy.loginfo("Mission aborted")
except TaskException, e:
    rospy.logerr("Exception caught: " + str(e))

if not rospy.core.is_shutdown():
    tc.SetManual()


rospy.loginfo("Mission completed")
