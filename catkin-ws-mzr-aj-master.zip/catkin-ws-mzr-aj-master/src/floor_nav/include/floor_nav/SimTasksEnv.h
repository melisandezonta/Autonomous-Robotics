#ifndef SIM_TASKS_ENV_H
#define SIM_TASKS_ENV_H

#include <ros/ros.h>
#include "task_manager_lib/TaskDefinition.h"
#include "std_msgs/String.h"
#include "geometry_msgs/Twist.h"
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/Pose2D.h"
#include "geometry_msgs/PoseStamped.h"
#include "sensor_msgs/BatteryState.h"
#include "kobuki_msgs/SensorState.h"
#include "nav_msgs/Path.h"
#include "sensor_msgs/LaserScan.h"
#include "pcl_ros/point_cloud.h"
#include "pcl/point_types.h"
#include <tf/transform_listener.h>
#include <tf/transform_datatypes.h>
#include "face_detect_base/detected_face.h"
#include <sensor_msgs/RegionOfInterest.h>
#include <exploration/ExplorerStatusUpdate.h>
#include <std_msgs/Bool.h>

namespace floor_nav {
    class SimTasksEnv : public task_manager_lib::TaskEnvironment {
    protected:
        bool paused;
        ros::Subscriber muxSub;
        ros::Subscriber pointCloudSub;
        ros::Subscriber pointCloud2DSub;
        ros::Subscriber laserscanSub;
        ros::Subscriber faceDetectionSub;
        ros::Publisher velPub;
        ros::Publisher pathPub;
        ros::Publisher goalPub;
        // Explorer
        ros::Publisher start_exploring_pub;
        ros::Subscriber status, twist_proxy_sub;
        ros::Subscriber status_battery_laptop, status_battery_kobuki;
        ros::ServiceClient muxClient;
        tf::TransformListener listener;

        void muxCallback(const std_msgs::String::ConstPtr &msg);
        void pointCloudCallback(const sensor_msgs::PointCloud2ConstPtr msg);
        void pointCloud2DCallback(const sensor_msgs::PointCloud2ConstPtr msg);
        void laserScanCallback(const sensor_msgs::LaserScanConstPtr msg);

        void faceDetectCallback(const face_detect_base::detected_face msg);

        void exploration_status_update_callback(const exploration::ExplorerStatusUpdate &status);

        void monitor_battery_laptop_callback(const sensor_msgs::BatteryState &status_battery_laptop);

        void monitor_battery_kobuki_callback(const kobuki_msgs::SensorState &status_battery_kobuki);

        void twist_proxy_callback(const geometry_msgs::Twist &twist);

        bool manualControl;
        std::string joystick_topic;
        std::string auto_topic;
        std::string base_frame;
        std::string reference_frame;
        pcl::PointCloud<pcl::PointXYZ> pointCloud;
        pcl::PointCloud<pcl::PointXYZ> pointCloud2D;

        face_detect_base::detected_face lastFaceArray;

        uint8_t exploration_status = 1;

        bool charging_laptop = false;
        float charge_level_laptop = 0;

        bool charging_kobuki = false;
        float charge_level_kobuki = 0;

    public:

        uint8_t getExplorationStatus() { return exploration_status; }

        uint8_t getChargingStatusLaptop() { return charging_laptop; }

        uint8_t getChargeLevelLaptop() { return charge_level_laptop; }

        uint8_t getChargingStatuskobuki() { return charging_kobuki; }

        uint8_t getChargeLevelKobuki() { return charge_level_kobuki; }

        SimTasksEnv(ros::NodeHandle &nh);

        ~SimTasksEnv() {};

        ros::NodeHandle &getNodeHandle() { return nh; }

        geometry_msgs::Pose2D getPose2D() const;

        geometry_msgs::Pose getPose() const;

        geometry_msgs::Pose2D convertRelativePose2D(geometry_msgs::Pose2D relativePose) const;

        geometry_msgs::PoseStamped getPoseStamped() const;

        const pcl::PointCloud<pcl::PointXYZ> &getPointCloud() const { return pointCloud; }

        const pcl::PointCloud<pcl::PointXYZ> &getPointCloud2D() const { return pointCloud2D; }

        void publish_goal(const double x, const double y, const double theta);

        void publishVelocity(double linear, double angular);

        void publishVelocity(double linear_x, double linear_y, double angular);

        void publishVelocity(const geometry_msgs::Twist &twist);

        void publishPath(const nav_msgs::Path &path);

        void setManualControl();

        void setComputerControl();

        bool getManualControl() const { return manualControl; }

        const std::string &getReferenceFrame() const { return reference_frame; }

        const std::string &getBaseFrame() const { return base_frame; }

        face_detect_base::detected_face getLastDetectedFaces() { return lastFaceArray; }

        void start_exploring() {
            std_msgs::Bool msg;
            msg.data = true;
            exploration_status = 0;
            start_exploring_pub.publish(std_msgs::Bool(msg));
        }

        void stop_exploring() {
            std_msgs::Bool msg;
            msg.data = false;
            exploration_status = 1;
            start_exploring_pub.publish(msg);
        }

    public: // To make point cloud work on 32bit system
        EIGEN_MAKE_ALIGNED_OPERATOR_NEW;
    };

};

#endif // SIM_TASKS_ENV_H
