
#include "floor_nav/SimTasksEnv.h"
#include <topic_tools/MuxSelect.h>
#include <boost/algorithm/string.hpp>
#include <sensor_msgs/BatteryState.h>
#include <kobuki_msgs/SensorState.h>

using namespace floor_nav;

SimTasksEnv::SimTasksEnv(ros::NodeHandle & n) : task_manager_lib::TaskEnvironment(n),
    paused(false), manualControl(true), joystick_topic("/teleop/twistCommand"), auto_topic("/mux/autoCommand"), base_frame("/bubbleRob"), reference_frame("/world")
{
    nh.getParam("joystick_topic",joystick_topic);
    nh.getParam("auto_topic",auto_topic);
    nh.getParam("base_frame",base_frame);
    nh.getParam("reference_frame",reference_frame);

    muxClient = nh.serviceClient<topic_tools::MuxSelect>("/mux/select");

    muxSub = nh.subscribe("/mux/selected",1,&SimTasksEnv::muxCallback,this);
    pointCloudSub = nh.subscribe("/vrep/depthSensor",1,&SimTasksEnv::pointCloudCallback,this);
    pointCloud2DSub = nh.subscribe("/vrep/hokuyoSensor",1,&SimTasksEnv::pointCloud2DCallback,this);
    laserscanSub = nh.subscribe("/scan",1,&SimTasksEnv::laserScanCallback,this);

    velPub = nh.advertise<geometry_msgs::Twist>(auto_topic,1);
    pathPub = nh.advertise<nav_msgs::Path>("/path",1);

    faceDetectionSub = nh.subscribe("/face_detect/rois_array", 1, &SimTasksEnv::faceDetectCallback, this);

    // Explorer/Planner
    start_exploring_pub = nh.advertise<std_msgs::Bool>("explore", 1);
    goalPub = nh.advertise<geometry_msgs::PoseStamped>("/move_base_simple/goal", 1);
    status = nh.subscribe("status_update", 1, &SimTasksEnv::exploration_status_update_callback, this);
    twist_proxy_sub = nh.subscribe("explorator_twist_command", 1, &SimTasksEnv::twist_proxy_callback, this);

    // Battery
    status_battery_laptop = nh.subscribe("/laptop_charge", 1, &SimTasksEnv::monitor_battery_laptop_callback, this);
    status_battery_kobuki = nh.subscribe("/mobile_base/sensors/core", 1, &SimTasksEnv::monitor_battery_kobuki_callback, this);
}

void SimTasksEnv::twist_proxy_callback(const geometry_msgs::Twist &twist) {
    if (exploration_status == 0) { publishVelocity(twist); }
}

void SimTasksEnv::exploration_status_update_callback(const exploration::ExplorerStatusUpdate &status) {
    ROS_INFO("Received status %d\n", status.type);
    exploration_status = status.type;
}

void SimTasksEnv::monitor_battery_laptop_callback(const sensor_msgs::BatteryState &status_battery_laptop) {
    charging_laptop = status_battery_laptop.power_supply_status == status_battery_laptop.POWER_SUPPLY_STATUS_CHARGING;
    charge_level_laptop = status_battery_laptop.percentage;
}

void SimTasksEnv::monitor_battery_kobuki_callback(const kobuki_msgs::SensorState &status_battery_kobuki) {
    charging_kobuki = status_battery_kobuki.charger != status_battery_kobuki.DISCHARGING;
    charge_level_kobuki = (status_battery_kobuki.battery / 160.) * 100;
}

void SimTasksEnv::setManualControl()
{
    topic_tools::MuxSelect select;
    select.request.topic = joystick_topic;
    if (!muxClient.call(select)) {
        ROS_ERROR("setManualControl: Failed to call service /mux/select");
    }
}

void SimTasksEnv::setComputerControl()
{
    topic_tools::MuxSelect select;
    select.request.topic = auto_topic;
    if (!muxClient.call(select)) {
        ROS_ERROR("setComputerControl: Failed to call service /mux/select");
    }
}

void SimTasksEnv::faceDetectCallback(const face_detect_base::detected_face msg) {
    lastFaceArray = msg;
}

geometry_msgs::Pose2D SimTasksEnv::getPose2D() const {
    geometry_msgs::Pose2D pose;
    tf::StampedTransform transform;
    try{
        listener.lookupTransform(reference_frame,base_frame, 
                ros::Time(0), transform);
    }
    catch (tf::TransformException &ex){
        ROS_ERROR("%s",ex.what());
    }
    pose.theta = tf::getYaw(transform.getRotation());
    pose.x = transform.getOrigin().x();
    pose.y = transform.getOrigin().y();
    return pose;
}

/**
 * Converts a relative pose to the reference frame.
 *
 * @param relativePose The pose to transform.
 * @return The relativePose in absolute coordinates.
 */
geometry_msgs::Pose2D SimTasksEnv::convertRelativePose2D(geometry_msgs::Pose2D relativePose) const {
    geometry_msgs::Pose2D pose;
    geometry_msgs::PoseStamped poseStamped, relativePoseStamped;
    relativePoseStamped.header.frame_id = getBaseFrame();
    relativePoseStamped.pose.position.x = relativePose.x;
    relativePoseStamped.pose.position.y = relativePose.y;
    relativePoseStamped.pose.orientation = tf::createQuaternionMsgFromYaw(relativePose.theta);
    tf::StampedTransform transform;
    try{
        listener.transformPose(reference_frame, relativePoseStamped, poseStamped);
        listener.lookupTransform(reference_frame,base_frame,
                                 ros::Time(0), transform);
    } catch (tf::TransformException &ex){
        ROS_ERROR("Error converting coordinates: %s",ex.what());
    }
    pose.theta = tf::getYaw(poseStamped.pose.orientation);
    pose.x = poseStamped.pose.position.x;
    pose.y = poseStamped.pose.position.y;
    return pose;
}



geometry_msgs::Pose SimTasksEnv::getPose() const {
    geometry_msgs::Pose pose;
    tf::StampedTransform transform;
    try{
        listener.lookupTransform(reference_frame,base_frame, 
                ros::Time(0), transform);
    }
    catch (tf::TransformException &ex){
        ROS_ERROR("%s",ex.what());
    }
    tf::quaternionTFToMsg(transform.getRotation(),pose.orientation);
    tf::pointTFToMsg(transform.getOrigin(),pose.position);
    return pose;
}

geometry_msgs::PoseStamped SimTasksEnv::getPoseStamped() const {
    geometry_msgs::PoseStamped pose;
    tf::StampedTransform transform;
    try{
        listener.lookupTransform(reference_frame,base_frame, 
                ros::Time(0), transform);
    }
    catch (tf::TransformException ex){
        ROS_ERROR("%s",ex.what());
    }
    tf::quaternionTFToMsg(transform.getRotation(),pose.pose.orientation);
    tf::pointTFToMsg(transform.getOrigin(),pose.pose.position);
    pose.header.frame_id = getReferenceFrame();
    pose.header.stamp = transform.stamp_;
    return pose;
}


void SimTasksEnv::publish_goal(const double x, const double y, const double theta) {
    geometry_msgs::PoseStamped msg;
    msg.header.stamp = ros::Time::now();
    msg.header.frame_id = getReferenceFrame();
    msg.pose.position.x = x;
    msg.pose.position.y = y;
    msg.pose.orientation = tf::createQuaternionMsgFromYaw(theta);
    exploration_status = 0;
    goalPub.publish(msg);
}

void SimTasksEnv::publishVelocity(double linear, double angular) {
    geometry_msgs::Twist cmd;
    if (paused) {
        cmd.linear.x = 0.;
        cmd.angular.z = 0.;
    } else {
        cmd.linear.x = linear;
        cmd.angular.z = angular;
    }
    publishVelocity(cmd);
}

void SimTasksEnv::publishVelocity(double linear_x, double linear_y, double angular) {
    geometry_msgs::Twist cmd;
    if (paused) {
        cmd.linear.x = 0.;
        cmd.linear.y = 0.;
        cmd.angular.z = 0.;
    } else {
        cmd.linear.x = linear_x;
        cmd.linear.y = linear_y;
        cmd.angular.z = angular;
    }
    publishVelocity(cmd);
}

void SimTasksEnv::publishVelocity(const geometry_msgs::Twist & twist) {
    geometry_msgs::Twist cmd;
    if (paused) {
        cmd.linear.x = 0.;
        cmd.linear.y = 0.;
        cmd.angular.z = 0.;
    } else {
        cmd = twist;
    }
    velPub.publish(cmd);
}

void SimTasksEnv::publishPath(const nav_msgs::Path &path) {
    pathPub.publish(path);
}

void SimTasksEnv::muxCallback(const std_msgs::String::ConstPtr& msg) {
    if (msg->data == joystick_topic) {
        manualControl = true;
    } else if (msg->data == auto_topic) {
        manualControl = false;
    } else {
        ROS_ERROR("Received unknown mux selection: '%s'",msg->data.c_str());
    }
}

void SimTasksEnv::pointCloudCallback(const sensor_msgs::PointCloud2ConstPtr msg) {
    pcl::fromROSMsg(*msg, pointCloud);
}

void SimTasksEnv::pointCloud2DCallback(const sensor_msgs::PointCloud2ConstPtr msg) {
    pcl::fromROSMsg(*msg, pointCloud2D);
}

void SimTasksEnv::laserScanCallback(const sensor_msgs::LaserScanConstPtr msg) {
    pointCloud2D.resize(msg->ranges.size());
    for (size_t i=0;i<msg->ranges.size();i++) {
        pointCloud2D[i].x = msg->ranges[i]*cos(msg->angle_min + i*msg->angle_increment);
        pointCloud2D[i].y = msg->ranges[i]*sin(msg->angle_min + i*msg->angle_increment);
    }
}



