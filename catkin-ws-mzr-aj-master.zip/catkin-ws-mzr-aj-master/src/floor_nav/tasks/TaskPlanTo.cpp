#include <math.h>
#include "TaskPlanTo.h"
#include "floor_nav/TaskPlanToConfig.h"
#include "geometry_msgs/PoseStamped.h"
#include "tf/transform_datatypes.h"

using namespace task_manager_msgs;
using namespace task_manager_lib;
using namespace floor_nav;

// #define DEBUG_PlanTo
#ifdef DEBUG_PlanTo
#warning Debugging task PlanTo
#endif


TaskIndicator TaskPlanTo::initialise() {
    ROS_INFO("Going to %.2f %.2f", cfg.goal_x, cfg.goal_y);

    env->publish_goal(cfg.goal_x, cfg.goal_y, cfg.goal_theta);

    return TaskStatus::TASK_INITIALISED;
}


TaskIndicator TaskPlanTo::iterate() {
    switch (env->getExplorationStatus()) {
        case 1:
            return TaskStatus::TASK_FAILED;
        case 2:
            return TaskStatus::TASK_COMPLETED;
        case 0:
        default:
            return TaskStatus::TASK_RUNNING;
    }
}

TaskIndicator TaskPlanTo::terminate() {
    env->stop_exploring();
    return TaskStatus::TASK_TERMINATED;
}


DYNAMIC_TASK(TaskFactoryPlanTo);
