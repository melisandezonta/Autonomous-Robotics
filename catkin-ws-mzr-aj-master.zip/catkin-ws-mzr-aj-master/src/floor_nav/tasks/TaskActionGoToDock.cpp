#include "TaskActionGoToDock.h"

using namespace floor_nav;
using namespace task_manager_msgs;
using namespace task_manager_lib;

DYNAMIC_TASK(TaskFactoryActionGoToDock<SimTasksEnv>);