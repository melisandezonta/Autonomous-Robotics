#include <math.h>
#include "TaskGoToPose.h"
#include "floor_nav/TaskGoToPoseConfig.h"

using namespace task_manager_msgs;
using namespace task_manager_lib;
using namespace floor_nav;

//#define DEBUG_GOTOPOSE
#ifdef DEBUG_GOTOPOSE
#warning Debugging task GOTO
#endif


TaskIndicator TaskGoToPose::initialise() {
    if (cfg.relative) {
        geometry_msgs::Pose2D relativeGoal;
        relativeGoal.x = cfg.goal_x;
        relativeGoal.y = cfg.goal_y;
        relativeGoal.theta = cfg.goal_theta;
        goal = env->convertRelativePose2D(relativeGoal);
#ifdef DEBUG_GOTOPOSE
        const geometry_msgs::Pose2D &tpose = env->getPose2D();
        ROS_INFO("Translated goal. %.2f %.2f %.2f + %.2f %.2f %.2f -> %.2f %.2f %.2f",
                 cfg.goal_x, cfg.goal_y, cfg.goal_theta * 180. / M_PI,
                 tpose.x, tpose.y, tpose.theta * 180. / M_PI,
                 goal.x, goal.y, goal.theta * 180. / M_PI);
#endif
    } else {
        goal.x = cfg.goal_x;
        goal.y = cfg.goal_y;
        goal.theta = cfg.goal_theta;
#ifdef DEBUG_GOTOPOSE
        ROS_INFO("Goal: %.2f %.2f %.2f", goal.x, goal.y, goal.theta * 180. / M_PI);
#endif
    }
    return TaskStatus::TASK_INITIALISED;
}


TaskIndicator TaskGoToPose::iterate() {
    const geometry_msgs::Pose2D &tpose = env->getPose2D();
    double dy = goal.y - tpose.y;
    double dx = goal.x - tpose.x;
    double r = hypot(dy, dx);
    if (r < cfg.dist_threshold) {
        // Align angle
        double diff = remainder(goal.theta - tpose.theta, 2 * M_PI);
#ifdef DEBUG_GOTOPOSE
        ROS_INFO("Angle: (goal - current) = (%.2f - %.2f) = %.2f",
                 goal.theta * 180. / M_PI, tpose.theta * 180. / M_PI, diff * 180. / M_PI);
#endif
        if (fabs(diff) > cfg.angle_threshold) {
            double rot = cfg.k_alpha * diff;
            env->publishVelocity(0, rot);
            return TaskStatus::TASK_RUNNING;
        } else {
            env->publishVelocity(0, 0);
            return TaskStatus::TASK_COMPLETED;
        }
    }


    if (cfg.holonomic) {
        double angle = -tpose.theta; // < 0 ? tpose.theta + 2*M_PI : tpose.theta;
        double cos_theta = cos(angle);
        double sin_theta = sin(angle);
        double vel_x = (dx * cos_theta - dy * sin_theta);
        double vel_y = (dx * sin_theta + dy * cos_theta);
#ifdef DEBUG_GOTOPOSE
        ROS_INFO("X=(%2.2f -> %2.2f) vX = %2.2f \t Y=(%2.2f -> %2.2f) vY=%2.2f th=%.1f", tpose.x, goal.x, vel_x, tpose.y, goal.y, vel_y, angle * 180. / M_PI);
#endif
        // Saturate values
        vel_x = std::max(std::min(cfg.k_v * vel_x, cfg.max_velocity), -cfg.max_velocity);
        vel_y = std::max(std::min(cfg.k_v * vel_y, cfg.max_velocity), -cfg.max_velocity);
        env->publishVelocity(vel_x, vel_y, 0);
    } else {
        double alpha = remainder(atan2(dy, dx) - tpose.theta, 2 * M_PI);
        if (!cfg.smart_method && fabs(alpha) > M_PI / 9) {
            double rot = ((alpha > 0) ? +1 : -1) * cfg.max_angular_velocity;
            env->publishVelocity(0, rot);
        } else {
            double vel = std::min(cfg.k_v * r, cfg.max_velocity);
            if (cfg.smart_method)
                vel *= std::exp(-(alpha * alpha) / (cfg.sigma * cfg.sigma));
            double rot = std::max(std::min(cfg.k_alpha * alpha, cfg.max_angular_velocity), -cfg.max_angular_velocity);
            env->publishVelocity(vel, rot);
        }
    }
    return TaskStatus::TASK_RUNNING;
}

TaskIndicator TaskGoToPose::terminate() {
    env->publishVelocity(0, 0);
    return TaskStatus::TASK_TERMINATED;
}

DYNAMIC_TASK(TaskFactoryGoToPose);
