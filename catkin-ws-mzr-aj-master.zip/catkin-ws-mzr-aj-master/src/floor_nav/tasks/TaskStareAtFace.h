#ifndef TASK_STARE_AT_FACE_H
#define TASK_STARE_AT_FACE_H

#include "task_manager_lib/TaskDefinition.h"
#include "floor_nav/SimTasksEnv.h"
#include "floor_nav/TaskStareAtFaceConfig.h"

using namespace task_manager_lib;

namespace floor_nav {
    class TaskStareAtFace : public TaskInstance<TaskStareAtFaceConfig,SimTasksEnv>
    {
        protected:
            ros::Time faceTime;
            sensor_msgs::RegionOfInterest trackedFace;
            bool tracking;
        public:
            TaskStareAtFace(TaskDefinitionPtr def, TaskEnvironmentPtr env) : Parent(def,env), tracking(false) {}

            virtual ~TaskStareAtFace() {};

            virtual TaskIndicator iterate();

    };
    class TaskFactoryStareAtFace : public TaskDefinition<TaskStareAtFaceConfig, SimTasksEnv, TaskStareAtFace>
    {

        public:
            TaskFactoryStareAtFace(TaskEnvironmentPtr env) :
                Parent("StareAtFace","Stare at that face a few seconds before turning away",true,env) {}
            virtual ~TaskFactoryStareAtFace() {};
    };
};

#endif // TASK_STARE_AT_FACE_H
