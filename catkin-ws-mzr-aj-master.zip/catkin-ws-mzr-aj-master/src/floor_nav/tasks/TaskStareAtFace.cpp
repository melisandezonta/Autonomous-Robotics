#include <math.h>
#include "TaskStareAtFace.h"
#include "floor_nav/TaskStareAtFaceConfig.h"

using namespace task_manager_msgs;
using namespace task_manager_lib;
using namespace floor_nav;

// #define DEBUG_GOTO


TaskIndicator TaskStareAtFace::iterate() {

    face_detect_base::detected_face faces = env->getLastDetectedFaces();

    if (!tracking) {
        if (faces.rois_array.empty())
            return TaskStatus::TASK_FAILED;
        else {
            trackedFace = faces.rois_array[0];
            faceTime = ros::Time::now();
            tracking = true;
        }
    } else {
        if (!faces.rois_array.empty())
            trackedFace = faces.rois_array[0];
    }

    // trackedFace is not NULL
    double diff = (cfg.frame_width / 2 - double(trackedFace.x_offset) - double(trackedFace.width) / 2);
    double angleDiff = remainder(atan2(diff, 1),2*M_PI);

    if (fabs(angleDiff) < cfg.angle_threshold) {
        if ((ros::Time::now() - faceTime).toSec() > 2.0) {
            return TaskStatus::TASK_COMPLETED;
        }
    } else {
        // Track face
        double rot = cfg.k_theta * angleDiff;
        if (rot > cfg.max_angular_velocity)  rot = cfg.max_angular_velocity;
        if (rot < -cfg.max_angular_velocity) rot = -cfg.max_angular_velocity;
        env->publishVelocity(0.0, rot);
    }
    return TaskStatus::TASK_RUNNING;
}

DYNAMIC_TASK(TaskFactoryStareAtFace);
