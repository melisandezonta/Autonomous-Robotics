#include <math.h>
#include "TaskActionExploration.h"
#include "floor_nav/TaskActionExplorationConfig.h"
#include <std_msgs/Empty.h>
#include <geometry_msgs/Twist.h>

using namespace task_manager_msgs;
using namespace task_manager_lib;
using namespace floor_nav;

// #define DEBUG_EXPLORATION
#ifdef DEBUG_EXPLORATION
#warning Debugging task EXPLORATION
#endif


TaskIndicator TaskActionExploration::initialise() {
    env->start_exploring();
    return TaskInstance::initialise();
}

TaskIndicator TaskActionExploration::iterate() {
    switch (env->getExplorationStatus()) {
        case 1:
            return TaskStatus::TASK_FAILED;
        case 2:
            return TaskStatus::TASK_COMPLETED;
        case 0:
        default:
            return TaskStatus::TASK_RUNNING;
    }
}


TaskIndicator TaskActionExploration::terminate() {
    env->stop_exploring();
    return TaskStatus::TASK_TERMINATED;
}

DYNAMIC_TASK(TaskFactoryActionExploration);
