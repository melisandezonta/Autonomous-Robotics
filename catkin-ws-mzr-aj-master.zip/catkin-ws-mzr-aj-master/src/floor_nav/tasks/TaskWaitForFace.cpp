#include <math.h>
#include "TaskWaitForFace.h"
#include "floor_nav/TaskWaitForFaceConfig.h"
using namespace task_manager_msgs;
using namespace task_manager_lib;
using namespace floor_nav;

TaskIndicator TaskWaitForFace::iterate() {
    const geometry_msgs::Pose2D & tpose = env->getPose2D();
    face_detect_base::detected_face faces = env->getLastDetectedFaces();
    if (faces.rois_array.size() > 0) {
        return TaskStatus::TASK_COMPLETED;
    }
	return TaskStatus::TASK_RUNNING;
}

DYNAMIC_TASK(TaskFactoryWaitForFace);