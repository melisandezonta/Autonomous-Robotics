#include <math.h>
#include "TaskMonitorBattery.h"
#include "floor_nav/TaskMonitorBatteryConfig.h"
#include <std_msgs/Empty.h>
#include <geometry_msgs/Twist.h>

using namespace task_manager_msgs;
using namespace task_manager_lib;
using namespace floor_nav;

// #define DEBUG_EXPLORATION
#ifdef DEBUG_EXPLORATION
#warning Debugging task EXPLORATION
#endif


TaskIndicator TaskMonitorBattery::iterate() {
    switch (env->getChargingStatusLaptop()) {
        case false:
            if (env->getChargeLevelLaptop() < 20)
                return TaskStatus::TASK_FAILED;
        case true:
        default:
            break;
    }
    switch (env->getChargingStatuskobuki()) {
        case false:
            if (env->getChargeLevelKobuki() < 20)
                return TaskStatus::TASK_FAILED;
        case true:
        default:
            break;
    }
    return TaskStatus::TASK_RUNNING;
}


TaskIndicator TaskMonitorBattery::terminate() {
    env->stop_exploring();
    return TaskStatus::TASK_TERMINATED;
}

DYNAMIC_TASK(TaskFactoryMonitorBattery);
