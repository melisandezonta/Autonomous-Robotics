#ifndef TASK_ACTIONEXPLORATION_H
#define TASK_ACTIONEXPLORATION_H

#include "task_manager_lib/TaskDefinition.h"
#include "floor_nav/SimTasksEnv.h"
#include "floor_nav/TaskActionExplorationConfig.h"
#include <exploration/ExplorerStatusUpdate.h>

using namespace task_manager_lib;

namespace floor_nav {
    class TaskActionExploration : public TaskInstance<TaskActionExplorationConfig, SimTasksEnv> {
    public:

        TaskActionExploration(TaskDefinitionPtr def, TaskEnvironmentPtr env) : Parent(def, env) {}

        virtual ~TaskActionExploration() {};

        virtual TaskIndicator initialise();

        virtual TaskIndicator iterate();

        virtual TaskIndicator terminate();
    };

    class TaskFactoryActionExploration
            : public TaskDefinition<TaskActionExplorationConfig, SimTasksEnv, TaskActionExploration> {

    public:
        TaskFactoryActionExploration(TaskEnvironmentPtr env) :
                Parent("Explore", "Launch the exploration", true, env) {}

        virtual ~TaskFactoryActionExploration() {};
    };
};

#endif // TASK_ACTIONEXPLORATION_H
