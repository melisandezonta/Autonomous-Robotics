#include <math.h>
#include "TaskPublishPath.h"
#include "nav_msgs/Path.h"
#include "floor_nav/TaskPublishPathConfig.h"
using namespace task_manager_msgs;
using namespace task_manager_lib;
using namespace floor_nav;



TaskIndicator TaskPublishPath::iterate()
{
    publishLastPose();
	return TaskStatus::TASK_RUNNING;
}

TaskIndicator TaskPublishPath::initialise() {
    publishLastPose();
    return TaskInstance::initialise();
}

void TaskPublishPath::publishLastPose() {
    geometry_msgs::PoseStamped tpose = env->getPoseStamped();
    poses.push_back(tpose);
    if (poses.size() > historySize) // Remove first element of vector
        poses.erase(poses.begin());
    nav_msgs::Path path;
    path.header = tpose.header;
    path.header.frame_id = "map";
    path.poses = poses;
    env->publishPath(path);
}

DYNAMIC_TASK(TaskFactoryPublishPath);
