#ifndef TASK_PUBLISH_PATH_H
#define TASK_PUBLISH_PATH_H

#include "task_manager_lib/TaskDefinition.h"
#include "floor_nav/SimTasksEnv.h"
#include "floor_nav/TaskPublishPathConfig.h"
#include "geometry_msgs/PoseStamped.h"
#include <vector>

using namespace task_manager_lib;

namespace floor_nav {
    class TaskPublishPath : public TaskInstance<TaskPublishPathConfig,SimTasksEnv>
    {
        protected:
            std::vector<geometry_msgs::PoseStamped> poses;
            int historySize;
            void publishLastPose();
        public:
            TaskPublishPath(TaskDefinitionPtr def, TaskEnvironmentPtr env) : Parent(def,env), historySize(500) {
                env->getNodeHandle().param("history_size", historySize, 500);
            }

        virtual TaskIndicator initialise() ;

        virtual ~TaskPublishPath() {};

        virtual TaskIndicator iterate();

    };
    class TaskFactoryPublishPath : public TaskDefinition<TaskPublishPathConfig, SimTasksEnv, TaskPublishPath>
    {
        public:
            TaskFactoryPublishPath(TaskEnvironmentPtr env) : 
                Parent("PublishPath","Do nothing until we reach a given destination",true,env) {}
            virtual ~TaskFactoryPublishPath() {};
    };
};

#endif // TASK_PUBLISH_PATH_H
