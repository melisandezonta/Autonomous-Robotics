#ifndef TASK_GOTO_DOCK_H
#define TASK_GOTO_DOCK_H

#include "task_manager_lib/TaskDefinition.h"
#include "floor_nav/SimTasksEnv.h"
#include <task_manager_action/TaskActionGeneric.h>
#include "floor_nav/TaskActionGoToDockConfig.h"
#include <move_base_msgs/MoveBaseAction.h>
#include <tf/transform_datatypes.h>
#include <kobuki_auto_docking/auto_docking_ros.hpp>
#include <task_manager_action/TaskActionGoToDockConfig.h>

using namespace task_manager_lib;
using namespace task_manager_action;

namespace floor_nav {
    template<class TaskEnvironment>
    class TaskActionGoToDock :
            public TaskActionGeneric<kobuki_msgs::AutoDockingAction, TaskActionGoToDockConfig, TaskEnvironment> {
    protected:
        typedef TaskActionGeneric <kobuki_msgs::AutoDockingAction,
                TaskActionGoToDockConfig, TaskEnvironment> Parent;

        const std::string actionName = "dock_drive_action";

        const std::string &getActionName() const {
            return actionName;
        }

        void buildActionGoal(typename Parent::Goal &goal) const {
            kobuki_msgs::AutoDockingGoal newGoal;
            goal = newGoal;
        }

    public:
        TaskActionGoToDock(TaskDefinitionPtr def, TaskEnvironmentPtr env) : Parent(def, env) {}

        virtual ~TaskActionGoToDock() {};
    };

    template<class TaskEnvironment>
    class TaskFactoryActionGoToDock :
            public task_manager_lib::TaskDefinition<TaskActionGoToDockConfig, TaskEnvironment, TaskActionGoToDock<TaskEnvironment> > {
    protected:
        typedef task_manager_lib::TaskDefinition<TaskActionGoToDockConfig, TaskEnvironment, TaskActionGoToDock<TaskEnvironment> > Parent;
    public:
        TaskFactoryActionGoToDock(TaskEnvironmentPtr env) :
                Parent("ActionGoToDock", "Publish an action to go to dock", true, env) {}

        virtual ~TaskFactoryActionGoToDock() {};
    };
};

#endif // TASK_GOTO_DOCK_H
