#ifndef TASK_MONITORBATTERY_H
#define TASK_MONITORBATTERY_H

#include "task_manager_lib/TaskDefinition.h"
#include "floor_nav/SimTasksEnv.h"
#include "floor_nav/TaskMonitorBatteryConfig.h"
#include <sensor_msgs/BatteryState.h>

using namespace task_manager_lib;

namespace floor_nav {
    class TaskMonitorBattery : public TaskInstance<TaskMonitorBatteryConfig, SimTasksEnv> {
    public:

        TaskMonitorBattery(TaskDefinitionPtr def, TaskEnvironmentPtr env) : Parent(def, env) {}

        virtual ~TaskMonitorBattery() {};

        virtual TaskIndicator iterate();

        virtual TaskIndicator terminate();
    };

    class TaskFactoryMonitorBattery : public TaskDefinition<TaskMonitorBatteryConfig, SimTasksEnv, TaskMonitorBattery> {

    public:
        TaskFactoryMonitorBattery(TaskEnvironmentPtr env) :
                Parent("MonitorBattery", "Monitor the battery", true, env) {}

        virtual ~TaskFactoryMonitorBattery() {};
    };
};

#endif // TASK_MONITORBATTERY_H
