# Autonomous Robotics

## Resources

* [Frontier exploration](https://pdfs.semanticscholar.org/9afb/8b6ee449e1ddf1268ace8efb4b69578b94f6.pdf)

## Todo

* [x] Fix acceleration issues
* [x] Fix path finder
* [x] Put on Turtlebot
* [x] Scan treasure
* [x] Scan Wifi
* [x] Create a map of Wifi
* [x] Add Obstacle Avoidance as a proxy (probably already done)
* [x] Explore on turtlebot
* [x] Handle battery
* [x] Add auto-docking
* [x] Add GoTo that does planning
* [x] Link battery to autodocking