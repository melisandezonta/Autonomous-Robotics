#include <vector>
#include <string>
#include <map>
#include <list>


#include <ros/ros.h>
#include <tf/tf.h>
#include <tf/transform_listener.h>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <nav_msgs/OccupancyGrid.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>


#define DEBUG 1

#define FREE 0xFF
#define UNKNOWN 0x80
#define OCCUPIED 0x00
#define WIN_SIZE 800

class OccupancyGridPlanner {
protected:
    ros::NodeHandle nh_;
    ros::Subscriber og_sub_;
    ros::Subscriber target_sub_;
    ros::Publisher path_pub_;
    tf::TransformListener listener_;

    cv::Rect roi_;
    cv::Mat_<uint8_t> og_, cropped_og_;
    cv::Mat_<cv::Vec3b> og_rgb_, og_rgb_marked_;
    cv::Point og_center_;
    nav_msgs::MapMetaData info_;
    std::string frame_id_;
    std::string base_link_;
    double radius;
    float heuristic_ratio;
    unsigned int neighbourhood_;
    bool ready;
    bool debug;

    // Replanning
    ros::Publisher target_pub_;
    geometry_msgs::PoseStampedConstPtr last_goal;
    /// A sorted queue of the elements on the path still unknown
    std::queue<cv::Point3i> planning_unknowns;

    typedef std::multimap<double, cv::Point3i> Heap3D;

    // Callback for Occupancy Grids
    void og_callback(const nav_msgs::OccupancyGridConstPtr &msg) {
        info_ = msg->info;
        frame_id_ = msg->header.frame_id;
        // Create an image to store the value of the grid.
        og_ = cv::Mat_<uint8_t>(msg->info.height, msg->info.width, 0xFF);
        og_center_ = cv::Point(-info_.origin.position.x / info_.resolution,
                               -info_.origin.position.y / info_.resolution);

        // Some variables to select the useful bounding box
        unsigned int maxx = 0, minx = msg->info.width,
                maxy = 0, miny = msg->info.height;
        cv::Point3i *unknown_point = NULL;
        //
        if (!planning_unknowns.empty()) {
            unknown_point = new cv::Point3i;
            *unknown_point = planning_unknowns.front();
        }
        bool found_unknowns = false;
        for (unsigned int j = 0; j < msg->info.height; j++) {
            for (unsigned int i = 0; i < msg->info.width; i++) {
                int8_t v = msg->data[j * msg->info.width + i];
                switch (v) {
                    case 0:
                        og_(j, i) = FREE;
                        break;
                    case 100:
                        og_(j, i) = OCCUPIED;
                        break;
                    case -1:
                    default:
                        og_(j, i) = UNKNOWN;
                        break;
                }
                // Was it unknown?
                if (unknown_point != NULL &&
                    (v == 0 || v == 100) &&
                    j == unknown_point->x &&
                    i == unknown_point->y) {
                    found_unknowns = true;
                    planning_unknowns.pop();
                    if (!planning_unknowns.empty()) {
                        unknown_point = &planning_unknowns.front();
                    } else {
                        unknown_point = NULL;
                    }
                }
                // Update the bounding box of free or occupied cells.
                if (og_(j, i) != UNKNOWN) {
                    minx = std::min(minx, i);
                    miny = std::min(miny, j);
                    maxx = std::max(maxx, i);
                    maxy = std::max(maxy, j);
                }
            }
        }
        if (!ready) {
            ready = true;
            ROS_INFO("Received occupancy grid, ready to plan");
        }
        int robot_size = static_cast<int>(radius / info_.resolution);
        cv::Mat element = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(2 * robot_size, 2 * robot_size));
        cv::erode(og_, og_, element);
        // The lines below are only for display
        unsigned int w = maxx - minx;
        unsigned int h = maxy - miny;
        // Convert the representation into something easy to display.
        roi_ = cv::Rect(minx, miny, w, h);
        cv::cvtColor(og_, og_rgb_, CV_GRAY2RGB);
        // Compute a sub-image that covers only the useful part of the
        // grid.
        cropped_og_ = cv::Mat_<uint8_t>(og_, roi_);
        if ((w > WIN_SIZE) || (h > WIN_SIZE)) {
            // The occupancy grid is too large to display. We need to scale
            // it first.
            double ratio = w / ((double) h);
            cv::Size new_size;
            if (ratio >= 1) {
                new_size = cv::Size(WIN_SIZE, WIN_SIZE / ratio);
            } else {
                new_size = cv::Size(WIN_SIZE * ratio, WIN_SIZE);
            }
            cv::Mat_<uint8_t> resized_og;
            cv::resize(cropped_og_, resized_og, new_size);
            cv::imshow("OccGrid", resized_og);
        } else {
            // cv::imshow( "OccGrid", cropped_og_ );
            cv::imshow("OccGrid", og_rgb_);
        }
        if (last_goal && found_unknowns)
            target_pub_.publish(last_goal);
    }

    // Generic test if a point is within the occupancy grid
    bool isInGrid(const cv::Point &P) {
        if ((P.x < 0) || (P.x >= (signed) info_.width)
            || (P.y < 0) || (P.y >= (signed) info_.height)) {
            return false;
        }
        return true;
    }

    double heuristic(cv::Point cell, cv::Point goal) {
        return heuristic_ratio * hypot(cell.x - goal.x, cell.y - goal.y);
    }

    float heuristicHeading(cv::Point3i cell, cv::Point3i goal) {
        return static_cast<float>(heuristic_ratio * hypot(hypot(cell.x - goal.x, cell.y - goal.y), cell.z - goal.z));
    }

    const cv::Point convertTo2D(cv::Point3i point3D) const {
        return cv::Point(point3D.x, point3D.y);
    }

// This is called when a new goal is posted by RViz. We don't use a
    // mutex here, because it can only be called in spinOnce.
    void target_callback(const geometry_msgs::PoseStampedConstPtr &msg) {
        tf::StampedTransform transform;
        last_goal = msg;
        geometry_msgs::PoseStamped pose;
        if (!ready) {
            ROS_WARN("Ignoring target while the occupancy grid has not been received");
            return;
        }
        if (last_goal == msg)
            ROS_INFO("Map updated, replanning...");
        else
            ROS_INFO("Received planning request");
        og_rgb_marked_ = og_rgb_.clone();
        // Convert the destination point in the occupancy grid frame.
        // The debug case is useful is the map is published without
        // gmapping running (for instance with map_server).
        if (debug) {
            pose = *msg;
        } else {
            // This converts target in the grid frame.
            listener_.waitForTransform(frame_id_, msg->header.frame_id, msg->header.stamp, ros::Duration(1.0));
            listener_.transformPose(frame_id_, *msg, pose);
            // this gets the current pose in transform
            listener_.lookupTransform(frame_id_, base_link_, ros::Time(0), transform);
        }
        // Now scale the target to the grid resolution and shift it to the
        // grid center.
        cv::Point target = cv::Point(pose.pose.position.x / info_.resolution, pose.pose.position.y / info_.resolution)
                           + og_center_;
        if (DEBUG)
            ROS_INFO("Planning target: %.2f %.2f -> %d %d",
                     pose.pose.position.x, pose.pose.position.y, target.x, target.y);
        cv::circle(og_rgb_marked_, target, 10, cv::Scalar(0, 0, 255));
        cv::imshow("OccGrid", og_rgb_marked_);
        if (!isInGrid(target)) {
            ROS_ERROR("Invalid target point (%.2f %.2f) -> (%d %d)",
                      pose.pose.position.x, pose.pose.position.y, target.x, target.y);
            return;
        }
        // Only accept target which are not OCCUPIED in the grid.
        if (og_(target) == OCCUPIED) {
            ROS_ERROR("Invalid target point: occupancy = %d", og_(target));
            return;
        }

        // Now get the current point in grid coordinates.
        cv::Point start;
        if (debug) {
            start = og_center_;
        } else {
            start = cv::Point(transform.getOrigin().x() / info_.resolution,
                              transform.getOrigin().y() / info_.resolution)
                    + og_center_;
        }
        if (DEBUG)
            ROS_INFO("Planning origin %.2f %.2f -> %d %d",
                     transform.getOrigin().x(), transform.getOrigin().y(), start.x, start.y);
        cv::circle(og_rgb_marked_, start, 10, cv::Scalar(0, 255, 0));
        cv::imshow("OccGrid", og_rgb_marked_);
        if (!isInGrid(start)) {
            ROS_ERROR("Invalid starting point (%.2f %.2f) -> (%d %d)",
                      transform.getOrigin().x(), transform.getOrigin().y(), start.x, start.y);
            return;
        }
        // If the starting point is not FREE there is a bug somewhere, but
        // better to check
        if (og_(start) != FREE) {
            ROS_ERROR("Invalid start point: occupancy = %d", og_(start));
            return;
        }
        cv::Mat_<cv::Vec3i> predecessor;

        // Convert start_yaw
        int s_yaw_index = (int) (round(tf::getYaw(transform.getRotation()) / M_PI_4) + 8) % 8;
        int t_yaw_index = (int) (round(tf::getYaw(pose.pose.orientation) / M_PI_4) + 8) % 8;
        cv::Point3i start3D(start.x, start.y, s_yaw_index);
        cv::Point3i target3D(target.x, target.y, t_yaw_index);

        cv::Mat_<float> cell_value = planPath3D(start3D, target3D, predecessor);

        std::cout << predecessor(target3D.x, target3D.y, target3D.z) << std::endl;
        if (isnan(cell_value(target3D.x, target3D.y, target3D.z))) {
            // No path found
            ROS_ERROR("No path found from (%d, %d) to (%d, %d)", start.x, start.y, target.x, target.y);
            return;
        }
        ROS_INFO("Planning completed");
        // Now extract the path by starting from goal and going through the
        // predecessors until the starting point
        nav_msgs::Path path = getPath3D(target3D, start3D, predecessor);
        path_pub_.publish(path);
        ROS_INFO("Request completed");
    }

    std::vector<cv::Point3i> rotate_90(std::vector<cv::Point3i> neighbors) {
        std::vector<cv::Point3i> result;
        std::vector<cv::Point3i>::iterator p;
        for (p = neighbors.begin(); p != neighbors.end(); ++p) {
            result.push_back(cv::Point3i(-p->y, p->x, p->z));
        }
        return result;
    }

    cv::Mat_<float>
    planPath3D(const cv::Point3i &start3D, const cv::Point3i &target3D, cv::Mat_<cv::Vec3i> &predecessor) {
        ROS_INFO("Starting planning from (%d, %d, %d) to (%d, %d, %d)",
                 start3D.x, start3D.y, start3D.z,
                 target3D.x, target3D.y, target3D.z);
        // Here the Dijskstra algorithm starts
        cv::Size og_size = og_.size();
        int sizes[] = {og_size.width, og_size.height, 8};
        // The best distance to the goal computed so far. This is
        // initialised with Not-A-Number.
        cv::Mat_<float> cell_value(3, sizes, NAN);
        // For each cell we need to store a pointer to the coordinates of
        // its best predecessor.
        predecessor = cv::Mat_<cv::Vec3i>(3, sizes);

        // The neighbour of a given cell in relative coordinates. The order
        // is important. If we use 4-connexity, then we can use only the
        // first 4 values of the array. If we use 8-connexity we use the
        // full array.
        cv::Point3i neighbours_face[5] = {
                cv::Point3i(1, 0, 0), // Go forward
                cv::Point3i(1, 1, 1), cv::Point3i(1, -1, -1), // Go in diagonal
                cv::Point3i(0, 0, 1), cv::Point3i(0, 0, -1), // Turn around
        };
        cv::Point3i neighbours_diagonal[5] = {
                cv::Point3i(1, 1, 0), // Go forward
                cv::Point3i(1, 0, -1), cv::Point3i(0, 1, 1), // Go in diagonal
                cv::Point3i(0, 0, 1), cv::Point3i(0, 0, -1), // Turn around
        };
        // Cost of displacement corresponding the neighbours. Diagonal
        // moves are 44% longer.
        double cost_face[5] = {1, sqrt(2) / 2, sqrt(2) / 2, 2.5, 2.5};
        double cost_diagonal[5] = {sqrt(2), 1.5, 1.5, 2.5, 2.5};

        std::vector<std::vector<cv::Point3i> > neighbours(8, std::vector<cv::Point3i>(5));
        neighbours[0] = std::vector<cv::Point3i>(neighbours_face, neighbours_face + 5);
        neighbours[1] = std::vector<cv::Point3i>(neighbours_diagonal, neighbours_diagonal + 5);
        for (int j = 2; j < 8; j += 2) {
            neighbours[j] = rotate_90(neighbours[j - 2]);
            neighbours[j + 1] = rotate_90(neighbours[j - 1]);
        }

        // The core of Dijkstra's Algorithm, a sorted heap, where the first
        // element is always the closer to the start.
        Heap3D heap;
        heap.insert(Heap3D::value_type(heuristicHeading(start3D, target3D), start3D));
        while (!heap.empty()) {
            // Select the cell at the top of the heap
            Heap3D::iterator hit = heap.begin();
            // the cell it contains is this_cell
            cv::Point3i this_cell = hit->second;
            // and its score is this_cost
            double this_cost = hit->first;
            // We can remove it from the heap now.
            heap.erase(hit);
            // Now see where we can go from this_cell
            for (unsigned int i = 0; i < 5; i++) {
                cv::Point3i dest = this_cell + neighbours[this_cell.z][i];
                dest.z = (dest.z + 8) % 8;
                assert(dest.z >= 0);
                assert(dest.z < 8);
                if (!isInGrid(convertTo2D(dest))) {
                    // outside the grid
                    continue;
                }
                uint8_t og = og_(convertTo2D(dest));
                if (og == OCCUPIED) {
                    // occupied -> skip
                    continue;
                }
                double cv = cell_value(dest.x, dest.y, dest.z);
                double move_cost = this_cell.z % 2 == 0 ? cost_face[i] : cost_diagonal[i];
                float new_cost = this_cost + move_cost;
                if (isnan(cv) || (new_cost < cv)) {
                    // found shortest path (or new path), updating the
                    // predecessor and the value of the cell
                    predecessor(dest.x, dest.y, dest.z) = cv::Vec3i(this_cell.x, this_cell.y, this_cell.z);
                    cell_value(dest.x, dest.y, dest.z) = new_cost;
                    // And insert the selected cells in the map.
                    heap.insert(Heap3D::value_type(new_cost + heuristicHeading(dest, target3D), dest));
                }
            }
        }
        return cell_value;
    }

    static bool sort_points(const cv::Point3i &a, const cv::Point3i &b) {
        return (a.x < b.x) || (a.x == b.x && a.y < b.y);
    }

    nav_msgs::Path getPath3D(cv::Point3i target3D, const cv::Point3i &start3D, cv::Mat_<cv::Vec3s> predecessor) {
        std::list<cv::Point3i> lpath;
        std::vector<cv::Point3i> unknowns;
        while (target3D != start3D) {
            if (og_(target3D.x, target3D.y) == UNKNOWN)
                unknowns.push_back(target3D);
            lpath.push_front(target3D);
            // Load predecessor
            cv::Vec3i p = predecessor(target3D.x, target3D.y, target3D.z);
            target3D.x = p[0];
            target3D.y = p[1];
            target3D.z = p[2];
        }
        lpath.push_front(start3D);
        // Save the unknowns
        std::sort(unknowns.begin(), unknowns.end(), sort_points);
        planning_unknowns = std::queue<cv::Point3i>();
        for (int i = 0; i < unknowns.size(); ++i) {
            planning_unknowns.push(unknowns[i]);
        }
        // Finally create a ROS path message
        nav_msgs::Path path;
        path.header.stamp = ros::Time::now();
        path.header.frame_id = frame_id_;
        path.poses.resize(lpath.size());
        std::list<cv::Point3i>::const_iterator it = lpath.begin();
        unsigned int ipose = 0;
        while (it != lpath.end()) {
            // time stamp is not updated because we're not creating a
            // trajectory at this stage
            path.poses[ipose].header = path.header;
            cv::Point3i P = *it;
            P.x -= og_center_.x;
            P.y -= og_center_.y;
            path.poses[ipose].pose.position.x = (P.x) * info_.resolution;
            path.poses[ipose].pose.position.y = (P.y) * info_.resolution;
            tf::Quaternion Q = tf::createQuaternionFromRPY(0, 0, P.z * M_PI_4);
            tf::quaternionTFToMsg(Q, path.poses[ipose].pose.orientation);
            ipose++;
            it++;
        }
        return path;
    }


public:
    OccupancyGridPlanner() : nh_("~"), radius(.1), debug(false), heuristic_ratio(0.1) {
        int nbour = 4;
        ready = false;
        nh_.param("base_frame", base_link_, std::string("/body"));
        nh_.param("radius", radius, radius);
        nh_.param("debug", debug, debug);
        nh_.param("neighbourhood", nbour, nbour);
        switch (nbour) {
            case 4:
                neighbourhood_ = nbour;
                break;
            case 8:
                neighbourhood_ = nbour;
                break;
            default:
                ROS_WARN("Invalid neighbourhood specification (%d instead of 4 or 8)", nbour);
                neighbourhood_ = 8;
        }
        og_sub_ = nh_.subscribe("occ_grid", 1, &OccupancyGridPlanner::og_callback, this);
        target_sub_ = nh_.subscribe("goal", 1, &OccupancyGridPlanner::target_callback, this);
        target_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("goal", 1, false);
        path_pub_ = nh_.advertise<nav_msgs::Path>("path", 1, true);
    }

};

int main(int argc, char *argv[]) {
    ros::init(argc, argv, "occgrid_planner");
    OccupancyGridPlanner ogp;
    cv::namedWindow("OccGrid", CV_WINDOW_AUTOSIZE);
    while (ros::ok()) {
        ros::spinOnce();
        if (cv::waitKey(50) == 'q') {
            ros::shutdown();
        }
    }
}

