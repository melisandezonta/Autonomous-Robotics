ros_task_manager
================

Generic Task Manager for ROS