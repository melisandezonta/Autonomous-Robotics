#include <vector>
#include <string>
#include <map>
#include <list>


#include <ros/ros.h>
#include <tf/tf.h>
#include <tf/transform_listener.h>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <nav_msgs/OccupancyGrid.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>
#include <std_msgs/Bool.h>
#include <wpa_cli/Scan.h>
#include <wpa_cli/Network.h>
#include <exploration/ExplorerStatusUpdate.h>

#include <boost/msm/front/euml/euml.hpp>
#include <boost/msm/front/euml/state_grammar.hpp>
#include <boost/msm/back/state_machine.hpp>
#include <iostream>

#define DEBUG 1

#define FREE 0xFF
#define FRONTIER 0xFE
#define OCCUPIED 0x00
#define UNKNOWN 0x80
#define WIN_SIZE 800

enum ExplorerState {
    Booting, Idle, Going, Failed, MapComplete
};

class Explorer {
    typedef std::vector<cv::Point> PointList;
    typedef std::tuple<cv::Point, int, PointList> FrontierRegion;
private:
    std_msgs::Bool MsgTrue;

    void send_fail() {
        exploration::ExplorerStatusUpdate update;
        update.type = update.FAILED;
        state = Failed;
        status_pub_.publish(update);
    }

    void send_reached() {
        exploration::ExplorerStatusUpdate update;
        update.type = update.REACHED;
        state = Idle;
        status_pub_.publish(update);
    }

    PointList update_frontiers(const std::vector<cv::Point> &frees) {
        frontiers = std::vector<cv::Point>();
        for (const cv::Point &p : frees) {
            for (int x = -1; x <= 1; x++) {
                for (int y = -1; y <= 1; y++) {
                    if (x == 0 && y == 0) continue;
                    if ((og_(p.y + y, p.x + x)) == (UNKNOWN)) {
                        og_(p.y, p.x) = FRONTIER;
                        frontiers.push_back(p);
                        break;
                    }
                }
            }
        }
        return frontiers;
    }

protected:
    // Attributes

    ros::NodeHandle nh_;
    ros::Subscriber og_sub_, explore_sub_;
    ros::Subscriber og_signal_sub_;
    ros::Subscriber target_sub_;
    ros::Publisher path_pub_, status_pub_;
    tf::TransformListener listener_;
    cv::Rect roi_;
    cv::Mat_<uint8_t> og_, cropped_og_;
    std::map<std::string, cv::Mat_<uint8_t> > networks_map;
    cv::Mat_<cv::Vec3b> og_rgb_, og_rgb_marked_;
    cv::Point og_center_;
    nav_msgs::MapMetaData info_;
    std::string frame_id_;
    std::string base_link_;
    double radius;
    float heuristic_ratio;
    unsigned int neighbourhood_;
    bool debug;

    // Replanning
    cv::Point3i const *last_goal{};
    /// A sorted queue of the elements on the path still unknown
    std::queue<cv::Point3i> planning_unknowns;

    /// The list of the last found frontiers.
    PointList frontiers;

    ExplorerState state;
    typedef std::multimap<double, cv::Point3i> Heap3D;

    /// Finds the next frontier and sends a goal to it.
    void explore_callback(const std_msgs::Bool start) {
        if (start.data) {
            switch (state) {
                // FIXME: Subscribe to status updates
                case Going:
                case Idle:
                    if (frontiers.empty())
                        send_fail();
                    else {
                        // Publish next frontier
                        cv::Point3i frontier;
                        const bool found = find_next_frontier(frontier);
                        if (found) publish_path_to_point(frontier);
                        else {
                            state = MapComplete;
                            send_reached();
                            break;
                        }
                    }
                    break;
                case MapComplete:
                    send_reached();
                case Booting:
                default:
                    send_fail();
            }
        } else {
            send_empty_path();
        }
    }


    const bool find_next_frontier(cv::Point3i &centroid3D) {
        const auto regions = extract_regions();
        if (regions.empty()) return true;

        const auto pose_now = fetch_current_pose();

        FrontierRegion const *closest_region = nullptr;
        int min_distance = INT_MAX;
        for (const auto &region : regions) {
            const auto &area = std::get<1>(region);
            if (area < 10.) continue; // Area too small, skip
            const auto &centroid = std::get<0>(region);
            auto distance = static_cast<const int>(hypot(centroid.x - pose_now.x, centroid.y - pose_now.y));
            if (distance < min_distance) {
                closest_region = &region;
                min_distance = distance;
            }
        }
        if (closest_region) {
            const auto &centroid = std::get<0>(*closest_region);
            centroid3D.x = centroid.x;
            centroid3D.y = centroid.y;
            centroid3D.z = 0; // FIXME
            return true;
        } else {
            return false;
        }
    }

    const std::vector<FrontierRegion> extract_regions() {
        std::vector<FrontierRegion> region_list;
        if (info_.height > 0 && info_.width > 0) {
            cv::Mat_<bool> visited = cv::Mat_<bool>(info_.height, info_.width, false);
            for (const auto &i : frontiers) {
                PointList points_in_region;
                int r = i.y;
                int c = i.x;
                if (visited(r, c)) continue;
                // FIFO of points to visit
                std::queue<cv::Point> heap;
                // Create new region from point
                heap.emplace(c, r);

                int maxr = r, minr = r, maxc = c, minc = c;
                while (!heap.empty()) {
                    const auto frontier = heap.front();
                    r = frontier.y;
                    c = frontier.x;
                    points_in_region.push_back(frontier);
                    visited(r, c) = true;
                    // Update mins/maxs
                    minr = std::min(minr, r);
                    maxr = std::max(maxr, r);
                    minc = std::min(minc, c);
                    maxc = std::max(maxc, c);
                    // Visit neighbors
                    for (int x = -1; x <= 1; x++) {
                        for (int y = -1; y <= 1; y++) {
                            if ((r + y) < visited.size[0] && (c + x) < visited.size[1] &&
                                (r + y) > 0 && (c + x) > 0) {
                                if (!visited(r + y, c + x) && og_(r + y, c + x) == FRONTIER) {
                                    // Add this point to the heap/region
                                    heap.emplace(c + x, r + y);
                                }
                                visited(r + y, c + x) = true;
                            }
                        }
                    }
                    heap.pop();
                }
                const int area = std::max((maxc - minc), (maxr - minr));
                region_list.emplace_back(compute_centroid(points_in_region), area, points_in_region);
            }
        }
        return region_list;
    }

    const cv::Point compute_centroid(PointList list) {
        int sum_x = 0;
        int sum_y = 0;
        for (auto &p : list) {
            sum_x += p.x;
            sum_y += p.y;
        }
        auto s = static_cast<int>(list.size());
        const cv::Point centroid(sum_x / s, sum_y / s);
        // Find the point in the list closest to the centroid
        cv::Point const *closest_point = nullptr;
        int min_distance = INT_MAX;
        for (const auto &point : list) {
            auto distance = static_cast<const int>(hypot(centroid.x - point.x, centroid.y - point.y));
            if (distance < min_distance) {
                closest_point = &point;
                min_distance = distance;
            }
        }
        return *closest_point;
    }

    // Callback for Occupancy Grids
    void og_callback(const nav_msgs::OccupancyGridConstPtr &msg) {
        info_ = msg->info;
        frame_id_ = msg->header.frame_id;
        // Create an image to store the value of the grid.
        og_ = cv::Mat_<uint8_t>(msg->info.height, msg->info.width, 0xFF);
        og_center_ = cv::Point(-info_.origin.position.x / info_.resolution,
                               -info_.origin.position.y / info_.resolution);

        // Some variables to select the useful bounding box
        unsigned int maxx = 0, minx = msg->info.width,
                maxy = 0, miny = msg->info.height;
        cv::Point3i *unknown_point = NULL;
        std::vector<cv::Point> frees;
        //
        if (!planning_unknowns.empty()) {
            unknown_point = new cv::Point3i;
            *unknown_point = planning_unknowns.front();
        }
        bool found_unknowns = false;
        for (unsigned int j = 0; j < msg->info.height; j++) {
            for (unsigned int i = 0; i < msg->info.width; i++) {
                int8_t v = msg->data[j * msg->info.width + i];
                switch (v) {
                    case 0:
                        og_(j, i) = FREE;
                        frees.emplace_back(i, j);
                        break;
                    case -1:
                        og_(j, i) = UNKNOWN;
                        break;
                    case 100:
                    default:
                        og_(j, i) = OCCUPIED;
                        break;
                }
                // Was it unknown?
                if (unknown_point != nullptr &&
                    (v == 0 || v == 100) &&
                    j == unknown_point->x &&
                    i == unknown_point->y) {
                    found_unknowns = true;
                    planning_unknowns.pop();
                    if (!planning_unknowns.empty()) {
                        unknown_point = &planning_unknowns.front();
                    } else {
                        unknown_point = nullptr;
                    }
                }


                // Update the bounding box of free or occupied cells.
                if ((og_(j, i)) != (UNKNOWN)) {
                    minx = std::min(minx, i);
                    miny = std::min(miny, j);
                    maxx = std::max(maxx, i);
                    maxy = std::max(maxy, j);
                }
            }
        }
        cv::circle(og_, fetch_current_pose(), static_cast<int>(radius / info_.resolution), FREE, CV_FILLED);

        update_frontiers(frees);

        // Convert the representation into something easy to display.
        unsigned int w = maxx - minx;
        unsigned int h = maxy - miny;
        roi_ = cv::Rect(minx, miny, w, h);
        cv::cvtColor(og_, og_rgb_, CV_GRAY2RGB);
        for (const cv::Point &p : frontiers) {
            og_rgb_(p.y, p.x)[0] = 0;
            og_rgb_(p.y, p.x)[1] = 0;
            og_rgb_(p.y, p.x)[2] = UINT8_MAX;
        }
        cv::Point3i target;
        if (find_next_frontier(target)) {
            og_rgb_(target.y, target.x)[0] = 0;
            og_rgb_(target.y, target.x)[1] = UINT8_MAX;
            og_rgb_(target.y, target.x)[2] = 0;
        }
        //cv::circle(og_rgb_marked_, convertTo2D(target3D), 10, cv::Scalar(0, 0, 255));
        const auto pose_now = fetch_current_pose();
        cv::circle(og_rgb_, pose_now, 10, cv::Scalar(0, 255, 0));
        // Compute a sub-image that covers only the useful part of the
        // grid.
        cropped_og_ = cv::Mat_<uint8_t>(og_, roi_);
        if ((w > WIN_SIZE) || (h > WIN_SIZE)) {
            // The occupancy grid is too large to display. We need to scale
            // it first.
            double ratio = w / ((double) h);
            cv::Size new_size;
            if (ratio >= 1) {
                new_size = cv::Size(WIN_SIZE, WIN_SIZE / ratio);
            } else {
                new_size = cv::Size(WIN_SIZE * ratio, WIN_SIZE);
            }
            cv::Mat_<uint8_t> resized_og;
            cv::resize(cropped_og_, resized_og, new_size);
            cv::flip(resized_og, resized_og, 0);
            cv::imshow("OccGridExplorer-resized", resized_og);
        } else {
            cv::flip(og_rgb_, og_rgb_, 0);
            cv::imshow("OccGridExplorer", og_rgb_);
        }
        if (state == Booting) state = Idle;
//        if (state == Going && found_unknowns) {
//            if (last_goal) {
//                publish_path_to_point(*last_goal);
//            } else {
//                explore_callback(MsgTrue);
//            }
//        }
    }

    const cv::Point fetch_current_pose() const {
        tf::StampedTransform transform;
        // this gets the current pose in transform
        listener_.lookupTransform(frame_id_, base_link_, ros::Time(0), transform);
        const auto x = static_cast<int>(transform.getOrigin().x() / info_.resolution + og_center_.x);
        const auto y = static_cast<int>(transform.getOrigin().y() / info_.resolution + og_center_.y);
        return cv::Point(x, y);
    }

    void og_signal_callback(const wpa_cli::Scan &msg) {
        const double alpha = 0.8;
        const int circle_size = 50;
        if (info_.height > 0 && info_.width > 0) {
            for (auto &network : msg.networks) {
                auto it = networks_map.find(network.ssid);
                if (it == networks_map.end()) {
                    // Does not exist yet
                    cv::Mat_<uint8_t> newly_inserted(info_.height, info_.width, (uint8_t) 0);
                    it = networks_map.insert(std::make_pair(network.ssid, newly_inserted)).first;
                }
                auto signal = -network.level;
                cv::Mat_<uint8_t> &og_signal_ = it->second;
                const auto pose_now = fetch_current_pose();
                // Declare
                cv::Mat_<uint8_t> new_og_signal(og_signal_.rows, og_signal_.cols, (uint8_t) 0);
                cv::Mat_<uint8_t> old_og_signal(og_signal_.rows, og_signal_.cols);
                cv::Mat_<uint8_t> sum_mask(og_signal_.rows, og_signal_.cols, (uint8_t) 0);
                // Circles
                cv::circle(new_og_signal, pose_now, circle_size, signal, CV_FILLED);
                cv::circle(sum_mask, pose_now, circle_size, UINT8_MAX, CV_FILLED);
                // Add with learning rate
                cv::convertScaleAbs(new_og_signal, new_og_signal, alpha);
                cv::convertScaleAbs(og_signal_, old_og_signal, (1 - alpha));
                cv::add(old_og_signal, new_og_signal, new_og_signal, sum_mask);
                // Add
                cv::circle(og_signal_, pose_now, circle_size, 0, CV_FILLED);
                cv::add(og_signal_, new_og_signal, og_signal_);
                std::stringstream title;
                title << "OccGrid_signal_" << network.ssid;
                cv::imshow(title.str(), og_signal_);
            }
        } else {
            ROS_INFO("Unknown map size, cannot initialize network signal map");
        }
    }

    // Generic test if a point is within the occupancy grid
    bool isInGrid3D(const cv::Point3i &P) const {
        return ((0 < P.x) && (P.x < (signed) info_.width)
                && (0 < P.y) && (P.y < (signed) info_.height));
    }


    float heuristicHeading(const cv::Point3i cell, const cv::Point3i goal) const {
        return static_cast<float>(heuristic_ratio * hypot(hypot(cell.x - goal.x, cell.y - goal.y), cell.z - goal.z));
    }

    const cv::Point convertTo2D(const cv::Point3i point3D) const {
        return cv::Point(point3D.x, point3D.y);
    }

    const bool same_targets(const cv::Point3i &p1, const cv::Point3i &p2) const {
        return (p1.x == p2.x && p1.y == p2.y && p1.z == p2.z);
    }

    void target_callback(const geometry_msgs::PoseStampedConstPtr &msg) {
        tf::StampedTransform transform;
        geometry_msgs::PoseStamped pose;
        // Convert the destination point in the occupancy grid frame.
        // The debug case is useful is the map is published without
        // gmapping running (for instance with map_server).
        if (debug) {
            pose = *msg;
        } else {
            // This converts target in the grid frame.
            listener_.waitForTransform(frame_id_, msg->header.frame_id, msg->header.stamp, ros::Duration(1.0));
            listener_.transformPose(frame_id_, *msg, pose);
            // this gets the current pose in transform
            listener_.lookupTransform(frame_id_, base_link_, ros::Time(0), transform);
        }

        const int t_yaw_index = (int) (round(tf::getYaw(pose.pose.orientation) / M_PI_4) + 8) % 8;
        cv::Point3i target3D(pose.pose.position.x / info_.resolution + og_center_.x,
                             pose.pose.position.y / info_.resolution + og_center_.y, t_yaw_index);

        const bool found = publish_path_to_point(target3D);
        if (!found) {
            // No path found
            ROS_ERROR("No path found to (%d, %d)", target3D.x, target3D.y);
            send_fail();
            return;
        }
    }

    bool publish_path_to_point(const cv::Point3i &target3D) {
        if (state == Booting) {
            ROS_WARN("Ignoring target while the occupancy grid has not been received");
            return false;
        }
        if (last_goal && same_targets(*last_goal, target3D)) ROS_INFO("Map updated, replanning...");
        else
            ROS_INFO("Received planning request");
        last_goal = &target3D;
        tf::StampedTransform transform;
        // this gets the current pose in transform
        listener_.lookupTransform(frame_id_, base_link_, ros::Time(0), transform);

        // Create start point
        int s_yaw_index = (int) (round(tf::getYaw(transform.getRotation()) / M_PI_4) + 8) % 8;
        cv::Point3i start3D(transform.getOrigin().x() / info_.resolution + og_center_.x,
                            transform.getOrigin().y() / info_.resolution + og_center_.y,
                            s_yaw_index);

        // Now get the current point in grid coordinates.
        if (DEBUG)
            ROS_INFO("Planning: (%d, %d) -> (%d, %d)", start3D.x, start3D.y, target3D.x, target3D.y);

        // Checks Target
        if (!isInGrid3D(target3D)) {
            ROS_ERROR("Invalid target point (%d %d)", target3D.x, target3D.y);
            return false;
        }
        // Only accept target which are not OCCUPIED in the grid.
        if (og_(convertTo2D(target3D)) == OCCUPIED) {
            ROS_ERROR("Invalid target point: occupancy = %d", og_(convertTo2D(target3D)));
            return false;
        }
        // Checks Start
        if (!isInGrid3D(start3D)) {
            ROS_ERROR("Invalid starting point: (%d, %d)", start3D.x, start3D.y);
            return false;
        }
        // If the starting point is not FREE there is a bug somewhere, but
        // better to check
        if (og_(convertTo2D(start3D)) != FREE) {
            ROS_ERROR("Invalid start point: occupancy = %d", og_(convertTo2D(start3D)));
            return false;
        }
        cv::Mat_<cv::Vec3i> predecessor;

        cv::Mat_<float> cell_value = planPath3D(start3D, target3D, predecessor);

        if (std::isnan(cell_value(target3D.x, target3D.y, target3D.z))) {
            // No path found
            ROS_ERROR("No path found from (%d, %d) to (%d, %d)", start3D.x, start3D.y, target3D.x, target3D.y);
            return false;
        }
        ROS_INFO("Planning completed");
        // Now extract the path by starting from goal and going through the
        // predecessors until the starting point
        nav_msgs::Path path = getPath3D(target3D, start3D, predecessor);
        path_pub_.publish(path);
        state = Going;
        ROS_INFO("Request completed");
        return true;
    }

    void send_empty_path() {
        nav_msgs::Path path;
        path.header.stamp = ros::Time::now();
        path.header.frame_id = frame_id_;
        path_pub_.publish(path);
    }

    std::vector<cv::Point3i> rotate_90(std::vector<cv::Point3i> neighbors) {
        std::vector<cv::Point3i> result;
        std::vector<cv::Point3i>::iterator p;
        for (p = neighbors.begin(); p != neighbors.end(); ++p) {
            result.emplace_back(-p->y, p->x, p->z);
        }
        return result;
    }

    cv::Mat_<float>
    planPath3D(const cv::Point3i &start3D, const cv::Point3i &target3D, cv::Mat_<cv::Vec3i> &predecessor) {
        ROS_INFO("Starting planning from (%d, %d, %d) to (%d, %d, %d)",
                 start3D.x, start3D.y, start3D.z,
                 target3D.x, target3D.y, target3D.z);
        // Here the Dijskstra algorithm starts
        cv::Size og_size = og_.size();
        int sizes[] = {og_size.width, og_size.height, 8};
        // The best distance to the goal computed so far. This is
        // initialised with Not-A-Number.
        cv::Mat_<float> cell_value(3, sizes, NAN);
        // For each cell we need to store a pointer to the coordinates of
        // its best predecessor.
        predecessor = cv::Mat_<cv::Vec3i>(3, sizes);

        // The neighbour of a given cell in relative coordinates. The order
        // is important. If we use 4-connexity, then we can use only the
        // first 4 values of the array. If we use 8-connexity we use the
        // full array.
        cv::Point3i neighbours_face[5] = {
                cv::Point3i(1, 0, 0), // Go forward
                cv::Point3i(1, 1, 1), cv::Point3i(1, -1, -1), // Go in diagonal
                cv::Point3i(0, 0, 1), cv::Point3i(0, 0, -1), // Turn around
        };
        cv::Point3i neighbours_diagonal[5] = {
                cv::Point3i(1, 1, 0), // Go forward
                cv::Point3i(1, 0, -1), cv::Point3i(0, 1, 1), // Go in diagonal
                cv::Point3i(0, 0, 1), cv::Point3i(0, 0, -1), // Turn around
        };
        // Cost of displacement corresponding the neighbours. Diagonal
        // moves are 44% longer.
        double cost_face[5] = {1, sqrt(2) / 2, sqrt(2) / 2, 10, 10};
        double cost_diagonal[5] = {sqrt(2), 1.5, 1.5, 10, 10};

        std::vector<std::vector<cv::Point3i> > neighbours(8, std::vector<cv::Point3i>(5));
        neighbours[0] = std::vector<cv::Point3i>(neighbours_face, neighbours_face + 5);
        neighbours[1] = std::vector<cv::Point3i>(neighbours_diagonal, neighbours_diagonal + 5);
        for (int j = 2; j < 8; j += 2) {
            neighbours[j] = rotate_90(neighbours[j - 2]);
            neighbours[j + 1] = rotate_90(neighbours[j - 1]);
        }

        // The core of Dijkstra's Algorithm, a sorted heap, where the first
        // element is always the closer to the start.
        Heap3D heap;
        heap.insert(Heap3D::value_type(heuristicHeading(start3D, target3D), start3D));
        while (!heap.empty()) {
            // Select the cell at the top of the heap
            Heap3D::iterator hit = heap.begin();
            // the cell it contains is this_cell
            const cv::Point3i this_cell = hit->second;
            // and its score is this_cost
            const double this_cost = hit->first;
            // We can remove it from the heap now.
            heap.erase(hit);
            // Now see where we can go from this_cell
            for (unsigned int i = 0; i < 5; i++) {
                cv::Point3i dest = this_cell + neighbours[this_cell.z][i];
                dest.z = (dest.z + 8) % 8;
                assert(dest.z >= 0);
                assert(dest.z < 8);
                if (!isInGrid3D(dest)) {
                    // outside the grid
                    continue;
                }
                uint8_t og = og_(convertTo2D(dest));
                if (og == OCCUPIED) {
                    // occupied -> skip
                    continue;
                }
                double cv = cell_value(dest.x, dest.y, dest.z);
                double move_cost = this_cell.z % 2 == 0 ? cost_face[i] : cost_diagonal[i];
                float new_cost = this_cost + move_cost;
                if (std::isnan(cv) || (new_cost < cv)) {
                    // found shortest path (or new path), updating the
                    // predecessor and the value of the cell
                    predecessor(dest.x, dest.y, dest.z) = cv::Vec3i(this_cell.x, this_cell.y, this_cell.z);
                    cell_value(dest.x, dest.y, dest.z) = new_cost;
                    // And insert the selected cells in the map.
                    heap.insert(Heap3D::value_type(new_cost + heuristicHeading(dest, target3D), dest));
                }
            }
        }
        return cell_value;
    }

    static bool sort_points(const cv::Point3i &a, const cv::Point3i &b) {
        return (a.x < b.x) || (a.x == b.x && a.y < b.y);
    }

    nav_msgs::Path getPath3D(cv::Point3i target3D, const cv::Point3i &start3D, cv::Mat_<cv::Vec3s> predecessor) {
        std::list<cv::Point3i> lpath;
        std::vector<cv::Point3i> unknowns;
        while (target3D != start3D) {
            if (og_(target3D.y, target3D.x) == UNKNOWN)
                unknowns.push_back(target3D);
            lpath.push_front(target3D);
            // Load predecessor
            cv::Vec3i p = predecessor(target3D.x, target3D.y, target3D.z);
            target3D.x = p[0];
            target3D.y = p[1];
            target3D.z = p[2];
        }
        lpath.push_front(start3D);
        // Save the unknowns
        std::sort(unknowns.begin(), unknowns.end(), sort_points);
        planning_unknowns = std::queue<cv::Point3i>();
        for (const auto &unknown : unknowns) {
            planning_unknowns.push(unknown);
        }
        // Finally create a ROS path message
        nav_msgs::Path path;
        path.header.stamp = ros::Time::now();
        path.header.frame_id = frame_id_;
        path.poses.resize(lpath.size());
        std::list<cv::Point3i>::const_iterator it = lpath.begin();
        unsigned int ipose = 0;
        while (it != lpath.end()) {
            // time stamp is not updated because we're not creating a
            // trajectory at this stage
            path.poses[ipose].header = path.header;
            cv::Point3i P = *it;
            P.x -= og_center_.x;
            P.y -= og_center_.y;
            path.poses[ipose].pose.position.x = (P.x) * info_.resolution;
            path.poses[ipose].pose.position.y = (P.y) * info_.resolution;
            tf::Quaternion Q = tf::createQuaternionFromRPY(0, 0, P.z * M_PI_4);
            tf::quaternionTFToMsg(Q, path.poses[ipose].pose.orientation);
            ipose++;
            it++;
        }
        return path;
    }

public:
    Explorer() : nh_("~"), radius(.1), debug(false), heuristic_ratio(0.1), state(Booting), last_goal(nullptr),
                 MsgTrue() {
        int nbour = 4;
        nh_.param("base_frame", base_link_, std::string("/base_link"));
        nh_.param("radius", radius, radius);
        nh_.param("debug", debug, debug);
        nh_.param("neighbourhood", nbour, nbour);
        switch (nbour) {
            case 4:
                neighbourhood_ = nbour;
                break;
            case 8:
                neighbourhood_ = nbour;
                break;
            default:
                ROS_WARN("Invalid neighbourhood specification (%d instead of 4 or 8)", nbour);
                neighbourhood_ = 8;
        }
        og_sub_ = nh_.subscribe("occ_grid", 1, &Explorer::og_callback, this);
        og_signal_sub_ = nh_.subscribe("occ_grid_signal", 1, &Explorer::og_signal_callback, this);
        explore_sub_ = nh_.subscribe("explore", 1, &Explorer::explore_callback, this);
        status_pub_ = nh_.advertise<exploration::ExplorerStatusUpdate>("status_update", 1, false);
        target_sub_ = nh_.subscribe("goal", 1, &Explorer::target_callback, this);
        path_pub_ = nh_.advertise<nav_msgs::Path>("path", 1, true);
        MsgTrue.data = true;
    }
};

int main(int argc, char *argv[]) {
    ros::init(argc, argv, "occgrid_planner");
    Explorer explorer;
    cv::namedWindow("OccGridExplorer", CV_WINDOW_AUTOSIZE);
    while (ros::ok()) {
        ros::spinOnce();
        if (cv::waitKey(50) == 'q') {
            ros::shutdown();
        }
    }
}

