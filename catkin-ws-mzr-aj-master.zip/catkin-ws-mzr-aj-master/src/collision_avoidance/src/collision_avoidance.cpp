#include "std_msgs/String.h"
#include "sensor_msgs/Joy.h"
#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_ros/point_cloud.h>

#define DEBUG_VERBOSE   5
#define DEBUG_JOYSTICK  4
#define DEBUG_COLLISION 3
#define DEBUG_WARNING   1
#define DEBUG_NONE      0

#define DEBUG_LVL DEBUG_COLLISION


class CollisionAvoidance {
protected:
    ros::Subscriber scanSub;
    ros::Subscriber cmdFromJoySub;
    ros::Publisher velPub;

    ros::NodeHandle nh;

    // This might be useful
    double radius;
    double stoppingDistance;
    double robotWidth;

    pcl::PointCloud<pcl::PointXYZ> lastpc;

    /// Publishes the requested velocity after modifying it
    /// to make sure the robot does't enter into collision with
    /// another object.
    void velocity_filter(const geometry_msgs::TwistConstPtr msg) {
        geometry_msgs::Twist filtered = findClosestAcceptableVelocity(*msg);
        velPub.publish(filtered);
    }

    /// Saves the last laser point scan.
    void pc_callback(const sensor_msgs::PointCloud2ConstPtr msg) {
        pcl::fromROSMsg(*msg, lastpc);
    }

    /**
     * Returns the appropriate velocity from a given joystick velocity.
     * Takes laser point scan into account.
     *
     * @param desired The joystick desired command
     * @return The closest acceptable velocity command
     */
    geometry_msgs::Twist findClosestAcceptableVelocity(const geometry_msgs::Twist &desired) {
        geometry_msgs::Twist res = desired;

        if (DEBUG_LVL >= DEBUG_JOYSTICK)
            ROS_INFO("[Collision Avoidance][Joystick] %f \t %f", desired.linear.x, desired.angular.z);

        double direction = desired.linear.x;

        bool result = true;
        size_t n = lastpc.size();
        for (unsigned int i = 0; i < n; i++) {
            float x = lastpc[i].x;
            float y = lastpc[i].y;
            if (hypotf(x, y) < 1e-2) {
                continue; // Unrelevant point, skip
            } else if (direction * x > 0) {
                // The point is in the direction of the movement
                double distance = std::sqrt(x * x + y * y);
                if (distance <= (radius + stoppingDistance)) {
                    // Avoid collision
                    double ratio = std::max(0.0, (distance - radius)/stoppingDistance);
                    double restrictedSpeed = ratio * direction;
                    res.linear.x = std::min(res.linear.x, restrictedSpeed);
                    if (DEBUG_LVL >= DEBUG_COLLISION)
                        ROS_INFO("[Collision Avoidance][Collision] Distance is %f. Ratio reduced to %f", distance, ratio);
                }
            }
        }

        return res;
    }

public:
    CollisionAvoidance() : nh("~"), radius(1.0), robotWidth(1.0), stoppingDistance(0.1) {
        // Subscribe/advertise
        scanSub =       nh.subscribe("scans", 1, &CollisionAvoidance::pc_callback, this);
        cmdFromJoySub = nh.subscribe("cmd_from_joy", 1, &CollisionAvoidance::velocity_filter, this);
        velPub =        nh.advertise<geometry_msgs::Twist>("output_vel", 1);
        // Retrieve parameters
        nh.param("radius", radius, 1.0);
        nh.param("robot_width", robotWidth, 1.0);
        nh.param("stopping_distance", stoppingDistance, 0.1);
    }
};

int main(int argc, char *argv[]) {
    ros::init(argc, argv, "collision_avoidance");

    CollisionAvoidance ca;

    ros::spin();
    // TODO: implement a security layer

    return 0;
}