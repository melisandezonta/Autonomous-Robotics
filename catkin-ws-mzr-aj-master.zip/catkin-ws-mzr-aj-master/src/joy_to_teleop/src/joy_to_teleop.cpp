#include "std_msgs/String.h"
#include "sensor_msgs/Joy.h"
#include <ros/ros.h>
#include <geometry_msgs/Twist.h>

#define DEBUG_VERBOSE   3
#define DEBUG_JOYSTICK  2
#define DEBUG_WARNING   1
#define DEBUG_NONE      0

#define DEBUG_LVL DEBUG_WARNING

#define L_X 0
#define L_Y 1
#define R_X 3
#define R_Y 4

class JoyToTeleop {
protected:
    ros::Subscriber joySub;
    ros::Publisher velPub;

    ros::NodeHandle nh; // The public node handle
    ros::NodeHandle nh_private; // The private node handle for parameters

    double linearRatio, angularRatio;

    void joystickCallback(const sensor_msgs::Joy::ConstPtr &msg) {
        if (DEBUG_LVL >= DEBUG_JOYSTICK)
            ROS_INFO("LEFT [%f,%f] \t RIGHT [%f,%f]", msg->axes[L_X], msg->axes[L_Y], msg->axes[R_X], msg->axes[R_Y]);

        geometry_msgs::Twist cmd;
        cmd.linear.x = linearRatio * msg->axes[L_Y];
        cmd.angular.z = angularRatio * msg->axes[L_X];

        velPub.publish(cmd);
    }

public:
    JoyToTeleop() : nh(""), nh_private("~"), linearRatio(), angularRatio() {
        // Subscribe/advertise
        joySub = nh.subscribe("joy", 1, &JoyToTeleop::joystickCallback, this);
        velPub = nh.advertise<geometry_msgs::Twist>("/cmd_vel", 1);

        nh_private.param("linear_ratio", linearRatio, 0.5);
        nh_private.param("angular_ratio", angularRatio, 0.7);
    }
};

int main(int argc, char *argv[]) {
    ros::init(argc, argv, "joy_to_teleop");

    JoyToTeleop jtt;

    ros::spin();

    return 0;
}