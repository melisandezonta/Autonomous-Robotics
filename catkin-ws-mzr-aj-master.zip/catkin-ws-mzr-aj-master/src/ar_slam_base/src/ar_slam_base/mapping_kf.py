import roslib; roslib.load_manifest('ar_mapping_base')
import rospy
from numpy import *
from numpy.linalg import inv
from math import pi, sin, cos
from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import Point, Pose, PoseStamped
import tf
import threading

import ar_loc_base
from ar_loc_base.rover_kinematics import *

seterr(all='raise')



class MappingKF(RoverKinematics):
    def __init__(self, initial_pose, initial_uncertainty):
        RoverKinematics.__init__(self)
        self.lock = threading.Lock()
        self.X = mat(vstack(initial_pose))
        self.P = mat(diag(initial_uncertainty))
        self.idx = {}
        self.pose_pub = rospy.Publisher("~pose",PoseStamped,queue_size=1)
        self.marker_pub = rospy.Publisher("~landmarks",MarkerArray,queue_size=1)

    def getRotation(self, theta):
        R = mat(zeros((2,2)))
        R[0,0] = cos(theta); R[0,1] = -sin(theta)
        R[1,0] = sin(theta); R[1,1] = cos(theta)
        return R

    def getDRotation(self, theta):
        R = mat(zeros((2, 2)))
        R[0, 0] = -sin(theta);
        R[0, 1] = -cos(theta)
        R[1, 0] = cos(theta);
        R[1, 1] = -sin(theta)
        return R
    
    def predict(self, motor_state, drive_cfg, encoder_precision):
        self.lock.acquire()
        # The first time, we need to initialise the state
        if self.first_run:
            self.motor_state.copy(motor_state)
            self.first_run = False
            self.lock.release()
            return (self.X, self.P)
        # print "-"*32
        # then compute odometry using least square
        iW = self.prepare_inversion_matrix(drive_cfg)
        S = self.prepare_displacement_matrix(self.motor_state,motor_state,drive_cfg)
        self.motor_state.copy(motor_state)
        
        # Implement Kalman prediction here
        theta = self.X[2]
        Rtheta = mat([[cos(theta), -sin(theta), 0],
                      [sin(theta),  cos(theta), 0],
                      [0, 0, 1]])
        dX = iW * S
        dX1, dX2 = dX[:2]
        A = mat([
            [1, 0, -dX1 * sin(theta) - dX2 * cos(theta)],
            [0, 1, dX1 * cos(theta) - dX2 * sin(theta)],
            [0, 0, 1],
        ])
        B = Rtheta * iW
        Q = mat(1e-5 * eye(3))
        Qu = mat(encoder_precision ** 2 * eye(B.shape[1]))

        self.X[0:3] += mat(Rtheta * dX)
        self.P[0:3, 0:3] = A * mat(self.P[0:3, 0:3]) * A.T + B * Qu * B.T + Q
        self.lock.release()
        return (self.X,self.P)


    def update_ar(self, Z, id, uncertainty):
        # Landmark id has been observed as Z with a given uncertainty
        self.lock.acquire()
        # print "Update: Z="+str(Z.T)+" X="+str(self.X.T)+" Id="+str(id)
        # Update the full state self.X and self.P based on landmark id
        # be careful that this might be the first time that id is observed
        if id in self.idx:
            idx = self.idx[id]
            self.__update_landmark(Z, idx, uncertainty)
        else:
            self.idx[id] = self.X.shape[0]

            theta = self.X[2]
            rot = self.getRotation(theta)
            L = mat(self.X[0:2]) + rot * mat(Z)
            new_X = mat(zeros((self.X.shape[0] + 2, self.X.shape[1])))
            new_X[:self.X.shape[0], :] = self.X
            new_X[self.X.shape[0]:, :] = L
            self.X = new_X

            R = mat(uncertainty ** 2 * eye(2))
            df_dz = rot
            Z1, Z2 = Z[:2]
            df_dx = mat([
                [1, 0, -Z1 * sin(theta) - Z2 * cos(theta)],
                [0, 1, Z1 * cos(theta) - Z2 * sin(theta)],
            ])
            # print(df_dx.shape, mat(self.P[0:3, 0:3]).shape, df_dx.T.shape, " + ",
            #       df_dz.shape, mat(R).shape, df_dz.T.shape)
            P_L = df_dx * mat(self.P[:3, :3]) * df_dx.T + \
                  df_dz * mat(R) * df_dz.T
            # print(self.P.shape, P_L)
            new_P = mat(zeros((self.P.shape[0] + 2, self.P.shape[1] + 2)))
            new_P[:self.P.shape[0], :self.P.shape[1]] = self.P
            new_P[self.P.shape[0]:, self.P.shape[1]:] = P_L
            self.P = new_P
        self.lock.release()
        return (self.X,self.P)

    def __update_landmark(self, Z, idx, uncertainty):
        rot = self.getRotation(self.X[2])
        X = mat(self.X[:2])
        L = mat(self.X[idx:idx+2])
        Zpredict = rot.T * (L - X)
        H = mat(zeros((len(Z), self.X.shape[0])))
        cos_t, sin_t = cos(self.X[2]), sin(self.X[2])
        X0, X1 = X
        L0, L1 = L
        H[0,0] = -cos_t
        H[0,1] = -sin_t
        H[0, 2] = (X0 - L0) * sin_t + (L1 - X1) * cos_t
        H[1,0] = sin_t
        H[1,1] = -cos_t
        H[1, 2] = (X0 - L0) * cos_t - (L1 - X1) * sin_t
        H[0,idx] = cos_t
        H[0,idx+1] = sin_t
        H[1,idx] = -sin_t
        H[1,idx+1] = cos_t
        R = mat(uncertainty ** 2 * eye(2))
        K = self.P * H.T * inv(H * self.P * H.T + mat(R))
        self.P = (eye(self.X.shape[0]) - K * H) * self.P
        self.X += K * (Z - Zpredict)

    def update_compass(self, Z, uncertainty):
        self.lock.acquire()
        print "Update: S=" + str(Z) + " X=" + str(self.X[:3].T)
        anglePredict = self.X[2]
        H = asmatrix(zeros((1, 3)))
        H[0, 2] = 1
        R = mat(uncertainty)
        K = self.P[:3, :3] * H.T * inv(H * self.P[:3, :3] * H.T + R)
        diff = Z - anglePredict
        diff -= 2 * pi if diff > pi else 0
        y = mat(diff)
        self.X[:3] += K * y
        self.P[:3, :3] = (eye(3) - K * H) * self.P[:3, :3]
        self.lock.release()
        return (self.X,self.P)


    def publish(self, target_frame, timestamp):
        pose = PoseStamped()
        pose.header.frame_id = target_frame
        pose.header.stamp = timestamp
        pose.pose.position.x = self.X[0,0]
        pose.pose.position.y = self.X[1,0]
        pose.pose.position.z = 0.0
        Q = tf.transformations.quaternion_from_euler(0, 0, self.X[2,0])
        pose.pose.orientation.x = Q[0]
        pose.pose.orientation.y = Q[1]
        pose.pose.orientation.z = Q[2]
        pose.pose.orientation.w = Q[3]
        self.pose_pub.publish(pose)
        ma = MarkerArray()
        marker = Marker()
        marker.header = pose.header
        marker.ns = "kf_uncertainty"
        marker.id = 5000
        marker.type = Marker.CYLINDER
        marker.action = Marker.ADD
        marker.pose = pose.pose
        marker.pose.position.z = -0.1
        marker.scale.x = 3*sqrt(self.P[0,0])
        marker.scale.y = 3*sqrt(self.P[1,1]);
        marker.scale.z = 0.1;
        marker.color.a = 1.0;
        marker.color.r = 0.0;
        marker.color.g = 1.0;
        marker.color.b = 1.0;
        ma.markers.append(marker)
        for id in self.idx.iterkeys():
            marker = Marker()
            marker.header.stamp = timestamp
            marker.header.frame_id = target_frame
            marker.ns = "landmark_kf"
            marker.id = id
            marker.type = Marker.CYLINDER
            marker.action = Marker.ADD
            l = self.idx[id]
            marker.pose.position.x = self.X[l,0]
            marker.pose.position.y = self.X[l+1,0]
            marker.pose.position.z = -0.1
            marker.pose.orientation.x = 0
            marker.pose.orientation.y = 0
            marker.pose.orientation.z = 1
            marker.pose.orientation.w = 0
            marker.scale.x = 3*sqrt(self.P[l,l])
            marker.scale.y = 3*sqrt(self.P[l+1,l+1]);
            marker.scale.z = 0.1;
            marker.color.a = 1.0;
            marker.color.r = 1.0;
            marker.color.g = 1.0;
            marker.color.b = 0.0;
            marker.lifetime.secs=3.0;
            ma.markers.append(marker)
            marker = Marker()
            marker.header.stamp = timestamp
            marker.header.frame_id = target_frame
            marker.ns = "landmark_kf"
            marker.id = 1000+id
            marker.type = Marker.TEXT_VIEW_FACING
            marker.action = Marker.ADD
            marker.pose.position.x = self.X[l+0,0]
            marker.pose.position.y = self.X[l+1,0]
            marker.pose.position.z = 1.0
            marker.pose.orientation.x = 0
            marker.pose.orientation.y = 0
            marker.pose.orientation.z = 1
            marker.pose.orientation.w = 0
            marker.text = str(id)
            marker.scale.x = 1.0
            marker.scale.y = 1.0
            marker.scale.z = 0.2
            marker.color.a = 1.0;
            marker.color.r = 1.0;
            marker.color.g = 1.0;
            marker.color.b = 1.0;
            marker.lifetime.secs=3.0;
            ma.markers.append(marker)
        self.marker_pub.publish(ma)

